package dev.phoenixfabric.core;

/**
 * Animation values recovered from the original PhoenixCapsuleRenderer bytecode.
 * Values are in model/render units; a Fabric block-entity renderer must apply them
 * to a PlayerModel and translate the rendered player by verticalOffset.
 */
public final class PhoenixCloneAnimation {
    private PhoenixCloneAnimation() {}

    public record Frame(float verticalOffset, float headPitch, float rightArmRoll,
                        float leftArmRoll, float rightLegPitch, float leftLegPitch,
                        float rightLegRoll, float leftLegRoll, float opacity, float scale) {}

    /**
     * @param worldTimeTicks client world tick time plus partial tick, matching the original renderer
     * @param printProgress smoothed progress in [0,1]
     * @param ready true when the clone has finished printing
     * @param quantumIsotope true for the original catalyst type that uses the smaller clone
     */
    public static Frame frame(float worldTimeTicks, float printProgress, boolean ready, boolean quantumIsotope) {
        float t = worldTimeTicks;
        float progress = clamp(printProgress, 0.0f, 1.0f);
        float headPitch = 0.22f + (float) Math.sin(t * 0.04f) * 0.03f;
        float armWave = (float) Math.cos(t * 0.03f) * 0.02f;
        float rightArmRoll = -0.16f - armWave;
        float leftArmRoll = 0.16f + armWave;
        float rightLegPitch = 0.06f;
        float leftLegPitch = 0.06f;
        float rightLegRoll = -0.05f;
        float leftLegRoll = 0.05f;
        float verticalOffset;
        float opacity;
        if (ready) {
            verticalOffset = (float) Math.sin(t * 0.06f) * 0.045f;
            opacity = 0.94f;
        } else {
            verticalOffset = (float) Math.sin(t * 0.15f) * 0.05f;
            opacity = clamp(0.4f + progress * 0.45f + verticalOffset, 0.35f, 0.9f);
        }
        return new Frame(verticalOffset, headPitch, rightArmRoll, leftArmRoll,
                rightLegPitch, leftLegPitch, rightLegRoll, leftLegRoll,
                opacity, quantumIsotope ? 0.35f : 0.7f);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
