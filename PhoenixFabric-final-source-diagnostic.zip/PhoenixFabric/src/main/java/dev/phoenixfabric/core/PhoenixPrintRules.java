package dev.phoenixfabric.core;

/**
 * Recovered gameplay rules from Rick's Stuff 0.0.4.3 PhoenixCapsuleBlockEntity.
 * This class deliberately contains no Minecraft/loader types so the rules can be
 * unit-tested independently and then wired into the Fabric block entity.
 */
public final class PhoenixPrintRules {
    public static final int REQUIRED_MEAT = 32;
    public static final int SLOT_MEAT = 0;
    public static final int SLOT_GLASS = 1;
    public static final int SLOT_WATER = 2;
    public static final int SLOT_CATALYST = 3;
    public static final int SLOT_DNA = 4;
    public static final int SLOT_HELMET = 5;
    public static final int SLOT_CHEST = 6;
    public static final int SLOT_LEGS = 7;
    public static final int SLOT_FEET = 8;
    public static final int SLOT_MAINHAND = 9;
    public static final int SLOT_OFFHAND = 10;
    public static final int INVENTORY_SIZE = 11;

    public enum Catalyst {
        NONE(0), QUANTUM_ISOTOPE(1), GOLDEN_APPLE(2), ENCHANTED_GOLDEN_APPLE(3), DARK_MATTER(4);
        private final int originalId;
        Catalyst(int originalId) { this.originalId = originalId; }
        public int originalId() { return originalId; }
    }

    public enum State { IDLE, PRINTING, READY, BROKEN }

    private PhoenixPrintRules() {}

    /** Exact original formula: max(20, seconds*20), quantum /3 (min 20), then corrupted *1.5. */
    public static int totalPrintTicks(int configuredSeconds, Catalyst catalyst, boolean corrupted) {
        int ticks = Math.max(20, Math.max(1, configuredSeconds) * 20);
        if (catalyst == Catalyst.QUANTUM_ISOTOPE) ticks = Math.max(20, ticks / 3);
        if (corrupted) ticks = (int) (ticks * 1.5f);
        return ticks;
    }

    /** A valid print needs an unbroken idle capsule, a profile-bearing DNA flask and 32 raw meat. */
    public static boolean canStart(State state, boolean dnaFlaskHasProfile, int rawMeatCount) {
        return state == State.IDLE && dnaFlaskHasProfile && rawMeatCount >= REQUIRED_MEAT;
    }

    /** Original repair requires two glass panes and one water bucket. */
    public static boolean canRepair(State state, int glassPaneCount, int waterBucketCount) {
        return state == State.BROKEN && glassPaneCount >= 2 && waterBucketCount >= 1;
    }

    public static int excessMeatReturned(int rawMeatCount) {
        return Math.max(0, rawMeatCount - REQUIRED_MEAT);
    }

    /** The original consumes one catalyst at print start, not after completion. */
    public static boolean consumesCatalyst(Catalyst catalyst) { return catalyst != Catalyst.NONE; }
}
