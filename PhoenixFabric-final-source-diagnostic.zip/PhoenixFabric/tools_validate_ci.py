#!/usr/bin/env python3
"""Static guard for the reproducible build workflow."""
from pathlib import Path
root = Path(__file__).resolve().parent
workflow = root / '.github/workflows/build.yml'
errors = []
if not workflow.is_file():
    errors.append('missing .github/workflows/build.yml')
else:
    text = workflow.read_text(encoding='utf-8')
    for needle in ("java-version: '25'", "gradle-version: '9.6'", 'gradle --no-daemon clean build --stacktrace', 'actions/upload-artifact@v4', 'build/libs/*.jar'):
        if needle not in text:
            errors.append(f'build workflow missing {needle!r}')
if errors:
    print('Phoenix CI validation: FAIL')
    print('\n'.join(errors))
    raise SystemExit(1)
print('Phoenix CI validation: PASS (workflow structure only; workflow not executed)')
