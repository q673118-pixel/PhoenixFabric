#!/usr/bin/env python3
"""Structural checks for the capsule menu integration (not a Minecraft compile)."""
from pathlib import Path
root = Path(__file__).parent
checks = {
    'menu class': root / 'src/main/java/dev/phoenixfabric/menu/PhoenixCapsuleMenu.java',
    'menu registry': root / 'src/main/java/dev/phoenixfabric/registry/PhoenixMenus.java',
    'screen class': root / 'src/client/java/dev/phoenixfabric/client/screen/PhoenixCapsuleScreen.java',
    'screen texture': root / 'src/main/resources/assets/phoenixfabric/textures/gui/phoenix_capsule.png',
}
missing = [name for name, path in checks.items() if not path.exists()]
if missing:
    raise SystemExit('Missing menu assets: ' + ', '.join(missing))
menu = checks['menu class'].read_text()
be = (root / 'src/main/java/dev/phoenixfabric/block/entity/PhoenixCapsuleBlockEntity.java').read_text()
block = (root / 'src/main/java/dev/phoenixfabric/block/PhoenixCapsuleBlock.java').read_text()
client = (root / 'src/client/java/dev/phoenixfabric/client/PhoenixFabricClient.java').read_text()
assert 'CAPSULE_SLOT_COUNT = 11' in menu
assert 'case 0 -> blockEntity.tryBeginPrint(30)' in menu
assert 'case 1 -> blockEntity.tryRepair()' in menu
assert 'implements PhoenixCapsuleRenderAccess, Container, MenuProvider' in be
assert 'return new PhoenixCapsuleMenu(containerId, inventory, this)' in be
assert 'player.openMenu(capsule)' in block
assert 'MenuScreens.register(PhoenixMenus.PHOENIX_CAPSULE, PhoenixCapsuleScreen::new)' in client
print('Phoenix capsule menu integration structural checks: PASS')
