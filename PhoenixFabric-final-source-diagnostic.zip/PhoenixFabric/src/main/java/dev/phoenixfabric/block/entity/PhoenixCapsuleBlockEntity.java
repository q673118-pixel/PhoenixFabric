package dev.phoenixfabric.block.entity;

import dev.phoenixfabric.api.PhoenixCapsuleRenderAccess;
import dev.phoenixfabric.block.PhoenixCapsuleBlock;
import dev.phoenixfabric.registry.PhoenixBlocks;
import dev.phoenixfabric.item.PhoenixDnaFlaskItem;
import dev.phoenixfabric.registry.PhoenixItems;
import dev.phoenixfabric.registry.PhoenixSounds;
import dev.phoenixfabric.core.PhoenixPrintRules;
import dev.phoenixfabric.menu.PhoenixCapsuleMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.NonNullList;
import net.minecraft.world.ContainerHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * Server-owned capsule state. Inventory/menu and player-profile resolution are
 * intentionally separate follow-up work; this class already persists the render
 * and print state so client rendering is not tied to transient fields.
 */
public final class PhoenixCapsuleBlockEntity extends BlockEntity implements PhoenixCapsuleRenderAccess, Container, MenuProvider {
    private static final String TAG_BROKEN = "PhoenixBroken";
    private static final String TAG_PRINTING = "PhoenixPrinting";
    private static final String TAG_READY = "PhoenixReady";
    private static final String TAG_PROGRESS = "PhoenixPrintProgress";
    private static final String TAG_PREVIOUS_PROGRESS = "PhoenixPreviousPrintProgress";
    private static final String TAG_PRINT_START = "PhoenixPrintStart";
    private static final String TAG_PRINT_DURATION = "PhoenixPrintDuration";
    private static final String TAG_CATALYST = "PhoenixCatalyst";
    private static final String TAG_SLIM = "PhoenixSlimSkin";
    private static final String TAG_SKIN = "PhoenixSkinTexture";

    private boolean broken;
    private boolean printing;
    private boolean ready;
    private float printProgress;
    private float previousPrintProgress;
    private long printStartGameTime;
    private int printDurationTicks = 30 * 20;
    private int catalystType;
    private boolean slimSkin;
    private Identifier skinTexture;
    private final NonNullList<ItemStack> items = NonNullList.withSize(PhoenixPrintRules.INVENTORY_SIZE, ItemStack.EMPTY);
    private java.util.UUID subjectUuid;
    private String subjectName = "";
    private boolean corruptedPrint;

    public PhoenixCapsuleBlockEntity(BlockPos pos, BlockState state) {
        super(PhoenixBlocks.PHOENIX_CAPSULE_ENTITY, pos, state);
        this.broken = state.hasProperty(PhoenixCapsuleBlock.BROKEN)
                && state.getValue(PhoenixCapsuleBlock.BROKEN);
        this.skinTexture = Identifier.withDefaultNamespace("textures/entity/player/wide/steve.png");
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, PhoenixCapsuleBlockEntity capsule) {
        if (level.isClientSide() || !capsule.printing || capsule.broken) return;
        capsule.previousPrintProgress = capsule.printProgress;
        long elapsed = Math.max(0L, level.getGameTime() - capsule.printStartGameTime);
        capsule.printProgress = Math.min(1.0f, (float) elapsed / Math.max(1, capsule.printDurationTicks));
        if (capsule.printProgress >= 1.0f) {
            capsule.printing = false;
            capsule.ready = true;
            level.playSound(null, pos, PhoenixSounds.CLONE_READY,
                    net.minecraft.sounds.SoundSource.BLOCKS, 0.9f, 1.0f);
        }
        capsule.setChanged();
        if (capsule.ready) level.sendBlockUpdated(pos, state, state, 3);
    }

    /** Validates and consumes the exact original inputs before beginning a print. Call on the server. */
    public boolean tryBeginPrint(int configuredSeconds) {
        if (level == null || level.isClientSide() || broken || printing || ready) return false;
        ItemStack dnaStack = items.get(PhoenixPrintRules.SLOT_DNA);
        java.util.Optional<PhoenixDnaFlaskItem.Profile> profile = dnaStack.is(PhoenixItems.DNA_FLASK)
                ? PhoenixDnaFlaskItem.readProfile(dnaStack) : java.util.Optional.empty();
        int meatCount = countRawMeat();
        if (profile.isEmpty() || meatCount < PhoenixPrintRules.REQUIRED_MEAT) return false;

        int catalyst = getCatalystType(items.get(PhoenixPrintRules.SLOT_CATALYST));
        boolean corrupted = items.get(PhoenixPrintRules.SLOT_MEAT).is(Items.ROTTEN_FLESH);
        int duration = PhoenixPrintRules.totalPrintTicks(configuredSeconds,
                switch (catalyst) {
                    case 1 -> PhoenixPrintRules.Catalyst.QUANTUM_ISOTOPE;
                    case 2 -> PhoenixPrintRules.Catalyst.GOLDEN_APPLE;
                    case 3 -> PhoenixPrintRules.Catalyst.ENCHANTED_GOLDEN_APPLE;
                    case 4 -> PhoenixPrintRules.Catalyst.DARK_MATTER;
                    default -> PhoenixPrintRules.Catalyst.NONE;
                }, corrupted);

        // Consume 32 accepted meat across the input stack; preserve any excess.
        int remaining = PhoenixPrintRules.REQUIRED_MEAT;
        for (int slot = PhoenixPrintRules.SLOT_MEAT; slot <= PhoenixPrintRules.SLOT_MEAT && remaining > 0; slot++) {
            ItemStack meat = items.get(slot);
            int used = Math.min(remaining, meat.getCount());
            meat.shrink(used);
            remaining -= used;
            if (meat.isEmpty()) items.set(slot, ItemStack.EMPTY);
        }
        dnaStack.shrink(1);
        if (dnaStack.isEmpty()) items.set(PhoenixPrintRules.SLOT_DNA, ItemStack.EMPTY);
        ItemStack catalystStack = items.get(PhoenixPrintRules.SLOT_CATALYST);
        if (catalyst != 0) {
            catalystStack.shrink(1);
            if (catalystStack.isEmpty()) items.set(PhoenixPrintRules.SLOT_CATALYST, ItemStack.EMPTY);
        }
        this.subjectUuid = profile.get().id();
        this.subjectName = profile.get().name();
        this.corruptedPrint = corrupted;
        boolean started = beginPrint(duration, catalyst, null, false);
        if (started) {
            level.playSound(null, worldPosition, PhoenixSounds.CLONE_PRINT_LOOP,
                    net.minecraft.sounds.SoundSource.BLOCKS, 0.65f, 1.0f);
        }
        return started;
    }

    /** Performs the original repair recipe: two glass panes and one water bucket. */
    public boolean tryRepair() {
        if (level == null || level.isClientSide() || !broken || printing || ready) return false;
        ItemStack glass = items.get(PhoenixPrintRules.SLOT_GLASS);
        ItemStack water = items.get(PhoenixPrintRules.SLOT_WATER);
        if (glass.getCount() < 2 || !glass.is(Items.GLASS_PANE) || !water.is(Items.WATER_BUCKET)) return false;

        glass.shrink(2);
        if (glass.isEmpty()) items.set(PhoenixPrintRules.SLOT_GLASS, ItemStack.EMPTY);
        // The reference mod returns a glass bottle for the repair water container.
        items.set(PhoenixPrintRules.SLOT_WATER, new ItemStack(Items.GLASS_BOTTLE));
        setBroken(false);
        setChanged();
        level.playSound(null, worldPosition, PhoenixSounds.CAPSULE_REPAIR,
                net.minecraft.sounds.SoundSource.BLOCKS, 0.8f, 1.0f);
        return true;
    }

    private int countRawMeat() {
        ItemStack stack = items.get(PhoenixPrintRules.SLOT_MEAT);
        return isRawMeat(stack) ? stack.getCount() : 0;
    }

    private static boolean isRawMeat(ItemStack stack) {
        return stack.is(Items.BEEF) || stack.is(Items.PORKCHOP) || stack.is(Items.CHICKEN)
                || stack.is(Items.MUTTON) || stack.is(Items.RABBIT) || stack.is(Items.ROTTEN_FLESH);
    }

    private static int getCatalystType(ItemStack stack) {
        if (stack.is(PhoenixItems.QUANTUM_ISOTOPE)) return 1;
        if (stack.is(Items.GOLDEN_APPLE)) return 2;
        if (stack.is(Items.ENCHANTED_GOLDEN_APPLE)) return 3;
        if (stack.is(PhoenixItems.DARK_MATTER_DUST)) return 4;
        return 0;
    }

    /** Low-level print transition; validated inventory calls tryBeginPrint. */
    public boolean beginPrint(int durationTicks, int catalystType, @Nullable Identifier skinTexture, boolean slimSkin) {
        if (level == null || level.isClientSide() || broken || printing || ready) return false;
        this.printing = true;
        this.ready = false;
        this.printProgress = 0.0f;
        this.previousPrintProgress = 0.0f;
        this.printStartGameTime = level.getGameTime();
        this.printDurationTicks = Math.max(20, durationTicks);
        this.catalystType = Math.max(0, catalystType);
        this.skinTexture = skinTexture == null
                ? Identifier.withDefaultNamespace("textures/entity/player/wide/steve.png") : skinTexture;
        this.slimSkin = slimSkin;
        setChanged();
        level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        return true;
    }

    public void setBroken(boolean broken) {
        boolean newlyBroken = broken && !this.broken;
        this.broken = broken;
        this.printing = false;
        this.ready = false;
        if (newlyBroken && level != null && !level.isClientSide()) {
            level.playSound(null, worldPosition, PhoenixSounds.CAPSULE_SHATTER,
                    net.minecraft.sounds.SoundSource.BLOCKS, 1.0f, 1.0f);
        }
        if (level != null && !level.isClientSide()) {
            BlockState state = getBlockState();
            if (state.hasProperty(PhoenixCapsuleBlock.BROKEN)) {
                level.setBlock(worldPosition, state.setValue(PhoenixCapsuleBlock.BROKEN, broken), 3);
            }
            setChanged();
        }
    }

    public void setReadyForRenderTest(boolean ready) {
        // Kept as a state setter for the future menu and tests; not exposed as a free-print interaction.
        this.ready = ready;
        this.printing = false;
        this.printProgress = ready ? 1.0f : 0.0f;
        this.previousPrintProgress = this.printProgress;
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putBoolean(TAG_BROKEN, broken);
        tag.putBoolean(TAG_PRINTING, printing);
        tag.putBoolean(TAG_READY, ready);
        tag.putFloat(TAG_PROGRESS, printProgress);
        tag.putFloat(TAG_PREVIOUS_PROGRESS, previousPrintProgress);
        tag.putLong(TAG_PRINT_START, printStartGameTime);
        tag.putInt(TAG_PRINT_DURATION, printDurationTicks);
        tag.putInt(TAG_CATALYST, catalystType);
        tag.putBoolean(TAG_SLIM, slimSkin);
        tag.putBoolean("PhoenixCorruptedPrint", corruptedPrint);
        if (subjectUuid != null) tag.putString("PhoenixSubjectUuid", subjectUuid.toString());
        tag.putString("PhoenixSubjectName", subjectName);
        ContainerHelper.saveAllItems(tag, items, registries);
        if (skinTexture != null) tag.putString(TAG_SKIN, skinTexture.toString());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        broken = tag.getBoolean(TAG_BROKEN).orElse(false);
        printing = tag.getBoolean(TAG_PRINTING).orElse(false);
        ready = tag.getBoolean(TAG_READY).orElse(false);
        printProgress = tag.getFloat(TAG_PROGRESS).orElse(0.0f);
        previousPrintProgress = tag.getFloat(TAG_PREVIOUS_PROGRESS).orElse(printProgress);
        printStartGameTime = tag.getLong(TAG_PRINT_START).orElse(0L);
        printDurationTicks = Math.max(20, tag.getInt(TAG_PRINT_DURATION).orElse(600));
        catalystType = tag.getInt(TAG_CATALYST).orElse(0);
        slimSkin = tag.getBoolean(TAG_SLIM).orElse(false);
        corruptedPrint = tag.getBoolean("PhoenixCorruptedPrint").orElse(false);
        subjectName = tag.getString("PhoenixSubjectName").orElse("");
        try { subjectUuid = java.util.UUID.fromString(tag.getString("PhoenixSubjectUuid").orElse("")); }
        catch (IllegalArgumentException ignored) { subjectUuid = null; }
        ContainerHelper.loadAllItems(tag, items, registries);
        String skin = tag.getString(TAG_SKIN).orElse("minecraft:textures/entity/player/wide/steve.png");
        skinTexture = Identifier.tryParse(skin);
        if (skinTexture == null) skinTexture = Identifier.withDefaultNamespace("textures/entity/player/wide/steve.png");
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag, registries);
        return tag;
    }

    @Override
    public @Nullable ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override public boolean phoenix$isBroken() { return broken || getBlockState().getValue(PhoenixCapsuleBlock.BROKEN); }
    @Override public boolean phoenix$isPrinting() { return printing; }
    @Override public boolean phoenix$isReady() { return ready; }
    @Override public int phoenix$getCatalystType() { return catalystType; }
    @Override public float phoenix$getFacingYawDegrees() {
        Direction facing = getBlockState().getValue(PhoenixCapsuleBlock.FACING);
        return facing.toYRot();
    }
    @Override public Identifier phoenix$getSkinTexture() { return skinTexture; }
    @Override public boolean phoenix$isSlimSkin() { return slimSkin; }
    @Override public java.util.UUID phoenix$getSubjectUuid() { return subjectUuid; }
    @Override public float phoenix$getSmoothPrintProgress(float partialTick) {
        if (printing && level != null) {
            long elapsed = Math.max(0L, level.getGameTime() - printStartGameTime);
            float liveProgress = Math.min(1.0f, (float) elapsed / Math.max(1, printDurationTicks));
            return Math.max(0.0f, Math.min(1.0f, liveProgress));
        }
        return Math.max(0.0f, Math.min(1.0f,
                previousPrintProgress + (printProgress - previousPrintProgress) * partialTick));
    }


    @Override
    public Component getDisplayName() {
        return Component.translatable("container.phoenixfabric.phoenix_capsule");
    }

    @Override
    public @Nullable AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new PhoenixCapsuleMenu(containerId, inventory, this);
    }

    // Container implementation used by the native capsule menu/screen.
    @Override public int getContainerSize() { return items.size(); }
    @Override public boolean isEmpty() { for (ItemStack stack : items) if (!stack.isEmpty()) return false; return true; }
    @Override public ItemStack getItem(int slot) { return slot >= 0 && slot < items.size() ? items.get(slot) : ItemStack.EMPTY; }
    @Override public ItemStack removeItem(int slot, int amount) {
        if (slot < 0 || slot >= items.size()) return ItemStack.EMPTY;
        ItemStack result = ContainerHelper.removeItem(items, slot, amount);
        if (!result.isEmpty()) setChanged();
        return result;
    }
    @Override public ItemStack removeItemNoUpdate(int slot) {
        if (slot < 0 || slot >= items.size()) return ItemStack.EMPTY;
        ItemStack result = ContainerHelper.takeItem(items, slot);
        if (!result.isEmpty()) setChanged();
        return result;
    }
    @Override public void setItem(int slot, ItemStack stack) {
        if (slot < 0 || slot >= items.size()) return;
        items.set(slot, stack.isEmpty() ? ItemStack.EMPTY : stack);
        if (!stack.isEmpty() && stack.getCount() > getMaxStackSize()) stack.setCount(getMaxStackSize());
        setChanged();
    }
    @Override public int getMaxStackSize() { return 64; }
    @Override public boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return level != null && !level.isClientSide() && player.distanceToSqr(
                worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) <= 64.0;
    }
    @Override public void clearContent() { for (int i = 0; i < items.size(); i++) items.set(i, ItemStack.EMPTY); setChanged(); }
    @Override public boolean canPlaceItem(int slot, ItemStack stack) {
        if (slot == PhoenixPrintRules.SLOT_MEAT) return isRawMeat(stack);
        if (slot == PhoenixPrintRules.SLOT_GLASS) return stack.is(Items.GLASS_PANE);
        if (slot == PhoenixPrintRules.SLOT_WATER) return stack.is(Items.WATER_BUCKET);
        if (slot == PhoenixPrintRules.SLOT_CATALYST) return getCatalystType(stack) != 0;
        if (slot == PhoenixPrintRules.SLOT_DNA) return stack.is(PhoenixItems.DNA_FLASK) && PhoenixDnaFlaskItem.readProfile(stack).isPresent();
        if (slot >= PhoenixPrintRules.SLOT_HELMET && slot <= PhoenixPrintRules.SLOT_OFFHAND) return true;
        return false;
    }
    public int getUiState() {
        if (broken) return 3;
        if (printing) return 1;
        if (ready) return 2;
        return 0;
    }

    public int getUiProgressPercent() {
        return Math.max(0, Math.min(100, Math.round(phoenix$getSmoothPrintProgress(1.0f) * 100.0f)));
    }

    public java.util.UUID getSubjectUuid() { return subjectUuid; }
    public String getSubjectName() { return subjectName; }
    public boolean isCorruptedPrint() { return corruptedPrint; }
}
