package dev.phoenixfabric.registry;

import dev.phoenixfabric.PhoenixFabric;
import dev.phoenixfabric.menu.PhoenixCapsuleMenu;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.inventory.MenuType;

/** Menu type registry for the capsule workstation. */
public final class PhoenixMenus {
    private PhoenixMenus() {}

    public static final MenuType<PhoenixCapsuleMenu> PHOENIX_CAPSULE = Registry.register(
            BuiltInRegistries.MENU,
            Identifier.fromNamespaceAndPath(PhoenixFabric.MOD_ID, "phoenix_capsule"),
            new MenuType<>(PhoenixCapsuleMenu::new, FeatureFlagSet.of())
    );

    public static void initialize() {
        PhoenixFabric.LOGGER.info("Registered Phoenix capsule menu type.");
    }
}
