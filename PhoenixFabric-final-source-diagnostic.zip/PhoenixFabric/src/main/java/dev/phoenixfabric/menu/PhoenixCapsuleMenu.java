package dev.phoenixfabric.menu;

import dev.phoenixfabric.block.entity.PhoenixCapsuleBlockEntity;
import dev.phoenixfabric.registry.PhoenixMenus;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.ItemStack;

/** Server-authoritative capsule menu. Container slots preserve the original 0..10 slot mapping. */
public final class PhoenixCapsuleMenu extends AbstractContainerMenu {
    public static final int CAPSULE_SLOT_COUNT = 11;
    private static final int PLAYER_INV_START = CAPSULE_SLOT_COUNT;
    private static final int PLAYER_INV_END = PLAYER_INV_START + 27;
    private static final int HOTBAR_START = PLAYER_INV_END;
    private static final int MENU_SLOT_COUNT = HOTBAR_START + 9;

    private final Container capsule;
    private final ContainerData data;

    /** Client constructor; the server synchronizes the real Block Entity container into this mirror. */
    public PhoenixCapsuleMenu(int containerId, Inventory playerInventory) {
        this(containerId, playerInventory, new SimpleContainer(CAPSULE_SLOT_COUNT), new SimpleContainerData(2));
    }

    /** Server constructor. */
    public PhoenixCapsuleMenu(int containerId, Inventory playerInventory, Container capsule) {
        this(containerId, playerInventory, capsule, new SimpleContainerData(2));
    }

    private PhoenixCapsuleMenu(int containerId, Inventory playerInventory, Container capsule, ContainerData data) {
        super(PhoenixMenus.PHOENIX_CAPSULE, containerId);
        checkContainerSize(capsule, CAPSULE_SLOT_COUNT);
        checkContainerDataCount(data, 2);
        this.capsule = capsule;
        this.data = data;
        capsule.startOpen(playerInventory.player);
        addDataSlots(data);

        // Main inputs: meat, DNA, catalyst, and repair supplies.
        addSlot(new Slot(capsule, 0, 26, 34));  // raw meat
        addSlot(new Slot(capsule, 4, 62, 34));  // DNA flask
        addSlot(new Slot(capsule, 3, 98, 34));  // catalyst
        addSlot(new Slot(capsule, 1, 26, 70));  // glass panes
        addSlot(new Slot(capsule, 2, 62, 70));  // water bucket

        // Six saved equipment slots: helmet, chest, legs, boots, main hand, off hand.
        addSlot(new Slot(capsule, 5, 160, 34));
        addSlot(new Slot(capsule, 6, 196, 34));
        addSlot(new Slot(capsule, 7, 232, 34));
        addSlot(new Slot(capsule, 8, 160, 70));
        addSlot(new Slot(capsule, 9, 196, 70));
        addSlot(new Slot(capsule, 10, 232, 70));

        // Player inventory and hotbar.
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 132 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInventory, col, 8 + col * 18, 190));
        }
    }

    @Override
    public void broadcastChanges() {
        if (capsule instanceof PhoenixCapsuleBlockEntity blockEntity) {
            data.set(0, blockEntity.getUiState());
            data.set(1, blockEntity.getUiProgressPercent());
        }
        super.broadcastChanges();
    }

    public int getUiState() { return data.get(0); }
    public int getUiProgressPercent() { return data.get(1); }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (player.level().isClientSide() || !(capsule instanceof PhoenixCapsuleBlockEntity blockEntity)) {
            return false;
        }
        return switch (id) {
            case 0 -> blockEntity.tryBeginPrint(30);
            case 1 -> blockEntity.tryRepair();
            default -> false;
        };
    }

    @Override
    public ItemStack quickMoveStack(Player player, int slotIndex) {
        if (slotIndex < 0 || slotIndex >= slots.size()) return ItemStack.EMPTY;
        Slot slot = slots.get(slotIndex);
        if (!slot.hasItem()) return ItemStack.EMPTY;

        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        boolean moved;
        if (slotIndex < PLAYER_INV_START) {
            moved = moveItemStackTo(stack, PLAYER_INV_START, MENU_SLOT_COUNT, true);
        } else {
            // Try only valid capsule slots. Slot.mayPlace delegates to Container.canPlaceItem.
            moved = moveItemStackTo(stack, 0, CAPSULE_SLOT_COUNT, false);
        }
        if (!moved) return ItemStack.EMPTY;
        if (stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
        else slot.setChanged();
        return original;
    }

    @Override
    public boolean stillValid(Player player) {
        return capsule.stillValid(player);
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        capsule.stopOpen(player);
    }
}
