package dev.phoenixfabric;

import net.fabricmc.api.ModInitializer;
import dev.phoenixfabric.registry.PhoenixBlocks;
import dev.phoenixfabric.registry.PhoenixItems;
import dev.phoenixfabric.registry.PhoenixMenus;
import dev.phoenixfabric.registry.PhoenixSounds;
import dev.phoenixfabric.event.PhoenixResurrectionEvents;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.world.item.CreativeModeTabs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Main Fabric entrypoint: registers the capsule block, item and block entity. */
public final class PhoenixFabric implements ModInitializer {
    public static final String MOD_ID = "phoenixfabric";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        PhoenixBlocks.initialize();
        PhoenixItems.initialize();
        PhoenixMenus.initialize();
        PhoenixSounds.initialize();
        PhoenixResurrectionEvents.register();
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(entries -> entries.accept(PhoenixBlocks.PHOENIX_CAPSULE_ITEM));
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(entries -> {
            entries.accept(PhoenixItems.DNA_FLASK);
            entries.accept(PhoenixItems.QUANTUM_ISOTOPE);
            entries.accept(PhoenixItems.DARK_MATTER_DUST);
        });
        LOGGER.info("Phoenix Protocol capsule runtime and resurrection event registered.");
    }
}
