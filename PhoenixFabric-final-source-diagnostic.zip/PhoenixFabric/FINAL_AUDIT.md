# PhoenixFabric alpha.12 — final planned checkpoint audit

## Scope
This is the final planned source checkpoint for the requested Minecraft 26.3 Fabric port of the supplied Rick's Stuff reference JAR. It consolidates the source stages, extracted reference assets, core rules, capsule block/entity, menu/screen, renderer/animation, DNA flask, resurrection logic and sound resources.

## Checks actually run in this environment

| Check | Result |
|---|---|
| `tools_validate_assets.py` | PASS |
| `tools_validate_menu.py` | PASS |
| `tools_validate_dna.py` | PASS |
| `tools_validate_sounds.py` | PASS |
| Dependency-free Java core self-test | PASS |
| Archive integrity | PASS (performed when packaging) |
| Gradle compile against Minecraft 26.3/Fabric | NOT RUN |
| Launch in Minecraft 26.3 | NOT RUN |
| In-game visual verification of capsule/clone animation/skin | NOT RUN |
| In-game death transfer and inventory restoration | NOT RUN |

## Why this is not a release JAR
The environment has Java 21, no installed Gradle executable and no Gradle wrapper in this project; this project targets Java 25. A real Fabric build and game launch could not be verified. The ZIP is source code, not an installable `.jar` or `.mcaddon`.

## Known gaps to resolve before calling it complete
1. `clone_print_loop.ogg` is triggered at print start but not continuously looped by a managed client sound instance.
2. Resurrection flash timing/color logic is present as a pure Java model, but is not connected to a live HUD rendering event.
3. The scan/laser visual effect is not implemented.
4. Skin resolution depends on the profile being known to the current client session; offline-profile texture resolution is not implemented.
5. All target-version Fabric/Minecraft APIs still need compilation and runtime testing. Static validators and pure Java tests do not prove the mod loads.

## Source of reference behavior
The supplied `ricks_stuff-0.0.4.3 (1).jar` is a Forge mod targeting Minecraft 1.20.1. The port targets the user-requested Minecraft 26.3 Fabric environment, so source/API compatibility is not automatic.

## Post-final follow-up — alpha.13
A review of the clone renderer found that it submitted the six base player model parts but omitted the six second-layer parts. This would hide hair/headwear, jacket, sleeves and trouser overlays from modern player skins. Alpha.13 submits those overlay parts and adds a static audit guard against losing them again. This is a source-level correction; it still requires a real Minecraft compile and visual test.


## Alpha.14 follow-up
A build configuration audit found Fabric Loader and Fabric API declared with plain Gradle `implementation`. These have been changed to Loom's `modImplementation` configuration, and a static guard script was added. This improves the project configuration but does not establish that the selected Minecraft/Fabric versions or Java APIs compile.

## Alpha.15 follow-up — reproducible external build
A GitHub Actions workflow was added to attempt a real build with Java 25 and Gradle 9.6 and publish the JAR as an artifact only if compilation succeeds. The workflow has not been executed from this environment. This is a route to obtaining a genuine compiler result, not a claim that the project compiles.

## Checks re-run for alpha.15
- `tools_validate_assets.py`: PASS
- `tools_validate_menu.py`: PASS
- `tools_validate_dna.py`: PASS
- `tools_validate_sounds.py`: PASS
- `tools_validate_build_config.py`: PASS (static only)
- `tools_validate_ci.py`: PASS (workflow structure only)
- `tools_final_audit.py`: PASS (static only)
- Dependency-free Java core self-test: PASS
- Gradle/Minecraft compile and in-game launch: NOT RUN in this environment


## Alpha.16 follow-up — fixed stale build-version validator
The previous build-config validator was hard-coded to require alpha.14, so it incorrectly failed after the project advanced to alpha.15. It now validates the alpha version format and Gradle resource-version expansion rather than a stale checkpoint number. Added `tools_run_all_checks.py` to run all static validators and compile/run the dependency-free Java core tests in one command.

Checks run for alpha.16:
- `python tools_run_all_checks.py` — PASS (all static validators and pure-Java core self-test).
- Minecraft/Fabric Gradle build — NOT RUN (no installed Gradle and Java runtime is 21, project targets Java 25).
- Minecraft 26.3 launch and in-game animation/death-transfer verification — NOT RUN.
