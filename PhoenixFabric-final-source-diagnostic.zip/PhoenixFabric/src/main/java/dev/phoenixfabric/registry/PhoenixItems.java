package dev.phoenixfabric.registry;

import dev.phoenixfabric.PhoenixFabric;
import dev.phoenixfabric.item.PhoenixDnaFlaskItem;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

/** Custom items used by the original Phoenix workflow. */
public final class PhoenixItems {
    private PhoenixItems() {}

    private static Item register(String path, Item item) {
        Identifier id = Identifier.fromNamespaceAndPath(PhoenixFabric.MOD_ID, path);
        return Registry.register(BuiltInRegistries.ITEM, id, item);
    }

    private static Item.Properties properties(String path) {
        Identifier id = Identifier.fromNamespaceAndPath(PhoenixFabric.MOD_ID, path);
        return new Item.Properties().setId(ResourceKey.create(Registries.ITEM, id));
    }

    public static final Item DNA_FLASK = register("dna_flask", new PhoenixDnaFlaskItem(properties("dna_flask").stacksTo(1)));
    public static final Item QUANTUM_ISOTOPE = register("quantum_isotope", new Item(properties("quantum_isotope")));
    public static final Item DARK_MATTER_DUST = register("dark_matter_dust", new Item(properties("dark_matter_dust")));

    public static void initialize() {
        PhoenixFabric.LOGGER.info("Registered Phoenix DNA flask and catalyst items.");
    }
}
