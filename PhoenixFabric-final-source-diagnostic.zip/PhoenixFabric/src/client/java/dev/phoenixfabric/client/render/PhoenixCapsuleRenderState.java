package dev.phoenixfabric.client.render;

import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.resources.Identifier;
import java.util.UUID;

/** Immutable-per-frame values copied from the block entity before render submission. */
public final class PhoenixCapsuleRenderState extends BlockEntityRenderState {
    public boolean broken;
    public boolean printing;
    public boolean ready;
    public float progress;
    public float yawDegrees;
    public float worldTimeTicks;
    public int catalystType;
    public Identifier skinTexture;
    public boolean slimSkin;
    public UUID subjectUuid;
    public String subjectName = "";
}
