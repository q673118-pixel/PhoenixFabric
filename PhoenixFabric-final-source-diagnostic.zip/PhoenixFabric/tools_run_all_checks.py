#!/usr/bin/env python3
"""Run every repository static validator plus dependency-free Java core tests.
This is not a Minecraft/Fabric compilation or game-launch test.
"""
from pathlib import Path
import subprocess, sys, tempfile
root = Path(__file__).resolve().parent
scripts = [
    'tools_validate_assets.py', 'tools_validate_build_config.py', 'tools_validate_ci.py',
    'tools_validate_dna.py', 'tools_validate_menu.py', 'tools_validate_sounds.py',
    'tools_final_audit.py'
]
for script in scripts:
    print(f'== {script} ==', flush=True)
    subprocess.run([sys.executable, str(root / script)], check=True)
with tempfile.TemporaryDirectory(prefix='phoenix-core-') as out:
    sources = sorted((root / 'src/main/java/dev/phoenixfabric/core').glob('*.java'))
    sources += sorted((root / 'src/test/java/dev/phoenixfabric/core').glob('*.java'))
    subprocess.run(['javac', '-d', out, *map(str, sources)], check=True)
    subprocess.run(['java', '-cp', out, 'dev.phoenixfabric.core.PhoenixCoreSelfTest'], check=True)
print('ALL AVAILABLE CHECKS: PASS (static checks + pure-Java tests; Minecraft/Fabric build not performed)')
