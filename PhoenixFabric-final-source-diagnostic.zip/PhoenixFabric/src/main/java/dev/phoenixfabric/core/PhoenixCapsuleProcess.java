package dev.phoenixfabric.core;

import java.util.Objects;
import java.util.UUID;

/** Server-authoritative print state machine recovered from the original block entity. */
public final class PhoenixCapsuleProcess {
    private PhoenixPrintRules.State state = PhoenixPrintRules.State.IDLE;
    private PhoenixPrintRules.Catalyst catalyst = PhoenixPrintRules.Catalyst.NONE;
    private boolean corrupted;
    private int progress;
    private int totalTicks = 600;
    private int configuredPrintSeconds = 30;
    private UUID ownerId;
    private String ownerName = "";

    public boolean start(UUID dnaProfileId, String dnaProfileName, int rawMeatCount,
                        PhoenixPrintRules.Catalyst insertedCatalyst, boolean rottenFleshWasUsed,
                        int configuredPrintSeconds) {
        Objects.requireNonNull(insertedCatalyst, "insertedCatalyst");
        if (!PhoenixPrintRules.canStart(state, dnaProfileId != null, rawMeatCount)) return false;
        ownerId = dnaProfileId;
        ownerName = dnaProfileName == null ? "" : dnaProfileName;
        catalyst = insertedCatalyst;
        corrupted = rottenFleshWasUsed;
        this.configuredPrintSeconds = Math.max(1, configuredPrintSeconds);
        totalTicks = PhoenixPrintRules.totalPrintTicks(this.configuredPrintSeconds, catalyst, corrupted);
        progress = 0;
        state = PhoenixPrintRules.State.PRINTING;
        return true;
    }

    /** Advance one server tick; returns true exactly once when printing completes. */
    public boolean tick() {
        if (state != PhoenixPrintRules.State.PRINTING) return false;
        progress++;
        if (progress >= totalTicks) {
            progress = totalTicks;
            state = PhoenixPrintRules.State.READY;
            return true;
        }
        return false;
    }

    /** Original resurrection consumes readiness and damages the capsule. */
    public boolean consumeForResurrection() {
        if (state != PhoenixPrintRules.State.READY) return false;
        state = PhoenixPrintRules.State.BROKEN;
        progress = 0;
        return true;
    }

    public boolean repair(int glassPanes, int waterBuckets) {
        if (!PhoenixPrintRules.canRepair(state, glassPanes, waterBuckets)) return false;
        state = PhoenixPrintRules.State.IDLE;
        progress = 0;
        catalyst = PhoenixPrintRules.Catalyst.NONE;
        corrupted = false;
        totalTicks = PhoenixPrintRules.totalPrintTicks(configuredPrintSeconds, PhoenixPrintRules.Catalyst.NONE, false);
        return true;
    }

    public void shatter() {
        state = PhoenixPrintRules.State.BROKEN;
        progress = 0;
    }

    public PhoenixPrintRules.State state() { return state; }
    public PhoenixPrintRules.Catalyst catalyst() { return catalyst; }
    public boolean corrupted() { return corrupted; }
    public int progress() { return progress; }
    public int totalTicks() { return totalTicks; }
    public UUID ownerId() { return ownerId; }
    public String ownerName() { return ownerName; }
}
