#!/usr/bin/env python3
"""Dependency-free structural validation for Phoenix Fabric JSON assets."""
import json
from pathlib import Path
root = Path(__file__).parent / 'src/main/resources'
errors=[]
for p in root.rglob('*.json'):
    try: data=json.loads(p.read_text(encoding='utf-8'))
    except Exception as e:
        errors.append(f'{p.relative_to(root)}: invalid JSON: {e}'); continue
    rel=p.relative_to(root).as_posix()
    if '/models/block/' in rel:
        if 'format_version' in data or 'texture_size' in data:
            errors.append(f'{rel}: contains Bedrock/Blockbench-only top-level fields')
        for i,el in enumerate(data.get('elements', [])):
            if len(el.get('from',[])) != 3 or len(el.get('to',[])) != 3:
                errors.append(f'{rel}: element {i} has malformed bounds')
            for face_name,face in el.get('faces',{}).items():
                tex=face.get('texture','')
                if tex.startswith('#') and tex[1:] not in data.get('textures',{}):
                    errors.append(f'{rel}: face {face_name} refers to missing texture variable {tex}')
    if '/blockstates/' in rel:
        raw=p.read_text(encoding='utf-8')
        if 'ricks_stuff:' in raw: errors.append(f'{rel}: stale original namespace remains')
if errors:
    print('\n'.join(errors)); raise SystemExit(1)
print('Phoenix asset JSON validation: PASS')
