package dev.phoenixfabric.item;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.component.CustomData;

import java.util.Optional;
import java.util.UUID;

/** DNA sample flask. Profile identity is stored on the item, not in transient client state. */
public final class PhoenixDnaFlaskItem extends Item {
    private static final String TAG_PROFILE_ID = "PhoenixProfileId";
    private static final String TAG_PROFILE_NAME = "PhoenixProfileName";

    public PhoenixDnaFlaskItem(Properties properties) { super(properties); }

    /**
     * Capture a live player's identity into the flask. The profile UUID is the
     * stable identity used later to resolve the subject's actual client skin.
     * This intentionally does not let arbitrary mobs become clone templates.
     */
    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player user, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof Player subject)) return InteractionResult.PASS;
        if (user.level().isClientSide()) return InteractionResult.SUCCESS;

        writeProfile(stack, subject.getUUID(), subject.getGameProfile().getName());
        user.displayClientMessage(Component.translatable(
                "item.phoenixfabric.dna_flask.captured", subject.getName()), true);
        return InteractionResult.SUCCESS;
    }

    public static void writeProfile(ItemStack stack, UUID profileId, String profileName) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        tag.putString(TAG_PROFILE_ID, profileId.toString());
        tag.putString(TAG_PROFILE_NAME, profileName == null ? "" : profileName);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }

    public static Optional<Profile> readProfile(ItemStack stack) {
        if (stack.isEmpty()) return Optional.empty();
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        String rawId = tag.getString(TAG_PROFILE_ID).orElse("");
        String name = tag.getString(TAG_PROFILE_NAME).orElse("");
        try {
            return Optional.of(new Profile(UUID.fromString(rawId), name));
        } catch (IllegalArgumentException ignored) {
            return Optional.empty();
        }
    }

    public record Profile(UUID id, String name) {}
}
