package dev.phoenixfabric.registry;

import dev.phoenixfabric.PhoenixFabric;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/** Original Phoenix capsule sounds extracted from the supplied Rick's Stuff JAR. */
public final class PhoenixSounds {
    private PhoenixSounds() {}

    public static final SoundEvent CLONE_PRINT_LOOP = register("clone_print_loop");
    public static final SoundEvent CLONE_READY = register("clone_ready");
    public static final SoundEvent CAPSULE_REPAIR = register("capsule_repair");
    public static final SoundEvent CAPSULE_SHATTER = register("capsule_shatter");

    private static SoundEvent register(String path) {
        Identifier id = Identifier.fromNamespaceAndPath(PhoenixFabric.MOD_ID, path);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    public static void initialize() {
        PhoenixFabric.LOGGER.info("Registered original Phoenix capsule sound events.");
    }
}
