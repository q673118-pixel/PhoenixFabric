#!/usr/bin/env python3
"""Structural checks for original Phoenix audio assets and event registration."""
import json
from pathlib import Path
root = Path(__file__).parent
assets = root / 'src/main/resources/assets/phoenixfabric'
entries = json.loads((assets / 'sounds.json').read_text())
required = {
    'clone_print_loop': 'clone_print_loop.ogg',
    'clone_ready': 'clone_ready.ogg',
    'capsule_repair': 'capsule_repair.ogg',
    'capsule_shatter': 'capsule_shatter.ogg',
}
for event, filename in required.items():
    assert event in entries, f'missing sound event {event}'
    sounds = entries[event].get('sounds', [])
    assert any(s.get('name') == f'phoenixfabric:{event}' for s in sounds), f'bad sound mapping for {event}'
    path = assets / 'sounds' / filename
    assert path.exists() and path.stat().st_size > 1000, f'missing/empty audio: {filename}'
registry = (root / 'src/main/java/dev/phoenixfabric/registry/PhoenixSounds.java').read_text()
for event in required:
    assert f'register("{event}")' in registry, f'{event} not registered in code'
be = (root / 'src/main/java/dev/phoenixfabric/block/entity/PhoenixCapsuleBlockEntity.java').read_text()
for sound in ['CLONE_PRINT_LOOP', 'CLONE_READY', 'CAPSULE_REPAIR', 'CAPSULE_SHATTER']:
    assert f'PhoenixSounds.{sound}' in be, f'{sound} not wired to block entity'
print('Phoenix sound validation: PASS')
