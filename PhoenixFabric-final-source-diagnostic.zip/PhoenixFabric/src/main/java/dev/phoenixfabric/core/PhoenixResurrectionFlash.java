package dev.phoenixfabric.core;

/** Pure timing/color model for the original Phoenix resurrection overlay. */
public final class PhoenixResurrectionFlash {
    public static final long DEFAULT_DURATION_MS = 2_400L;
    public static final long INITIAL_FLASH_MS = 400L;

    public record Rgb(int red, int green, int blue) {
        public Rgb {
            red = clamp(red); green = clamp(green); blue = clamp(blue);
        }
        private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }
        public int argb(int alpha) {
            return (clamp(alpha) << 24) | (red << 16) | (green << 8) | blue;
        }
    }

    public record Frame(boolean visible, float progress, float flashAlpha, float edgeAlpha,
                        Rgb flashColor, Rgb edgeColor) {}

    private PhoenixResurrectionFlash() {}

    /** Mirrors the original overlay's catalyst/corruption palette. */
    public static Rgb flashColor(PhoenixPrintRules.Catalyst catalyst, boolean corrupted) {
        if (catalyst == PhoenixPrintRules.Catalyst.QUANTUM_ISOTOPE) return new Rgb(120, 240, 255);
        if (catalyst == PhoenixPrintRules.Catalyst.GOLDEN_APPLE
                || catalyst == PhoenixPrintRules.Catalyst.ENCHANTED_GOLDEN_APPLE) return new Rgb(255, 230, 100);
        if (corrupted) return new Rgb(140, 160, 60);
        return new Rgb(180, 255, 200);
    }

    public static Rgb edgeColor(PhoenixPrintRules.Catalyst catalyst, boolean corrupted) {
        if (catalyst == PhoenixPrintRules.Catalyst.QUANTUM_ISOTOPE) return new Rgb(10, 100, 140);
        if (catalyst == PhoenixPrintRules.Catalyst.GOLDEN_APPLE
                || catalyst == PhoenixPrintRules.Catalyst.ENCHANTED_GOLDEN_APPLE) return new Rgb(140, 100, 10);
        if (corrupted) return new Rgb(80, 80, 20);
        return new Rgb(15, 120, 40);
    }

    /** Returns the frame at elapsed milliseconds; alpha values are normalized 0..1. */
    public static Frame frame(long elapsedMs, long requestedDurationMs,
                              PhoenixPrintRules.Catalyst catalyst, boolean corrupted) {
        long duration = requestedDurationMs > 0 ? requestedDurationMs : DEFAULT_DURATION_MS;
        if (elapsedMs < 0 || elapsedMs >= duration) {
            return new Frame(false, 1.0f, 0.0f, 0.0f, flashColor(catalyst, corrupted), edgeColor(catalyst, corrupted));
        }
        float progress = Math.min(1.0f, (float) elapsedMs / (float) duration);
        float flashAlpha = elapsedMs < INITIAL_FLASH_MS
                ? (1.0f - (float) elapsedMs / INITIAL_FLASH_MS) * 0.85f : 0.0f;
        float edgeEnvelope = progress < 0.25f ? progress / 0.25f : 1.0f - (progress - 0.25f) / 0.75f;
        float edgeAlpha = Math.max(0.0f, Math.min(1.0f, edgeEnvelope)) * 0.55f;
        return new Frame(true, progress, flashAlpha, edgeAlpha, flashColor(catalyst, corrupted), edgeColor(catalyst, corrupted));
    }
}
