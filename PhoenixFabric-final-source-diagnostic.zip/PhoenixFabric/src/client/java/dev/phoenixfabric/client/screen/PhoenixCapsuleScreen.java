package dev.phoenixfabric.client.screen;

import dev.phoenixfabric.menu.PhoenixCapsuleMenu;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.Font;
import net.minecraft.world.entity.player.Inventory;

/** Custom operation terminal for capsule inputs, saved loadout, print and repair actions. */
public final class PhoenixCapsuleScreen extends AbstractContainerScreen<PhoenixCapsuleMenu> {
    private static final Identifier BACKGROUND = Identifier.fromNamespaceAndPath(
            "phoenixfabric", "textures/gui/phoenix_capsule.png");

    public PhoenixCapsuleScreen(PhoenixCapsuleMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 276;
        this.imageHeight = 222;
        this.titleLabelX = 8;
        this.titleLabelY = 7;
        this.inventoryLabelX = 8;
        this.inventoryLabelY = 119;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.translatable("gui.phoenixfabric.phoenix_capsule.print_clone"), button -> {
            if (minecraft != null && minecraft.gameMode != null) {
                minecraft.gameMode.handleInventoryButtonClick(menu.containerId, 0);
            }
        }).bounds(leftPos + 17, topPos + 94, 118, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.phoenixfabric.phoenix_capsule.repair_tank"), button -> {
            if (minecraft != null && minecraft.gameMode != null) {
                minecraft.gameMode.handleInventoryButtonClick(menu.containerId, 1);
            }
        }).bounds(leftPos + 141, topPos + 94, 118, 20).build());
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractBackground(graphics, mouseX, mouseY, delta);
        graphics.blit(RenderPipelines.GUI_TEXTURED, BACKGROUND, leftPos, topPos,
                0.0F, 0.0F, imageWidth, imageHeight, imageWidth, imageHeight);
        Component stateLabel = switch (menu.getUiState()) {
            case 1 -> Component.translatable("gui.phoenixfabric.phoenix_capsule.synthesizing");
            case 2 -> Component.translatable("gui.phoenixfabric.phoenix_capsule.stasis");
            case 3 -> Component.translatable("gui.phoenixfabric.phoenix_capsule.breached");
            default -> Component.translatable("gui.phoenixfabric.phoenix_capsule.standby");
        };
        graphics.text(font, stateLabel, leftPos + 137, topPos + 8,
                menu.getUiState() == 3 ? 0xFFFF5555 : 0xFFB9F7E8, false);
        graphics.text(font, Component.literal(menu.getUiProgressPercent() + "%"),
                leftPos + 239, topPos + 18, 0xFFB9F7E8, false);
        graphics.fill(leftPos + 137, topPos + 20, leftPos + 232, topPos + 24, 0xFF071115);
        int progressWidth = Math.max(0, Math.min(95, menu.getUiProgressPercent() * 95 / 100));
        if (progressWidth > 0) {
            graphics.fill(leftPos + 137, topPos + 20, leftPos + 137 + progressWidth, topPos + 24, 0xFF57D6B4);
        }
    }
}
