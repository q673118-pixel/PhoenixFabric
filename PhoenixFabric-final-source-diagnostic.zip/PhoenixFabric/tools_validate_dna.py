#!/usr/bin/env python3
"""Structural validation of DNA capture and online skin/model resolution."""
import json
from pathlib import Path
root = Path(__file__).parent
item = (root / 'src/main/java/dev/phoenixfabric/item/PhoenixDnaFlaskItem.java').read_text()
access = (root / 'src/main/java/dev/phoenixfabric/api/PhoenixCapsuleRenderAccess.java').read_text()
be = (root / 'src/main/java/dev/phoenixfabric/block/entity/PhoenixCapsuleBlockEntity.java').read_text()
renderer = (root / 'src/client/java/dev/phoenixfabric/client/render/PhoenixCapsuleRenderer.java').read_text()
checks = {
    'right-click player capture': 'interactLivingEntity' in item and 'writeProfile(stack, subject.getUUID()' in item,
    'non-player rejection': 'if (!(target instanceof Player subject)) return InteractionResult.PASS;' in item,
    'stable subject UUID render contract': 'UUID phoenix$getSubjectUuid()' in access and 'phoenix$getSubjectUuid() { return subjectUuid; }' in be,
    'client profile lookup': 'connection.getPlayerInfo(state.subjectUuid)' in renderer,
    'actual skin texture': 'playerSkin.texture()' in renderer,
    'slim model detection': 'PlayerSkin.Model.SLIM' in renderer,
}
for name, passed in checks.items():
    if not passed:
        raise SystemExit(f'FAIL: {name}')
for locale in ('en_us.json', 'ru_ru.json'):
    data = json.loads((root / 'src/main/resources/assets/phoenixfabric/lang' / locale).read_text())
    assert 'item.phoenixfabric.dna_flask.captured' in data
print('Phoenix DNA capture / online skin resolution structural validation: PASS')
