package dev.phoenixfabric.core;

import java.util.UUID;

/** Dependency-free smoke tests; run with `java ...PhoenixCoreSelfTest` after compiling test sources. */
public final class PhoenixCoreSelfTest {
    public static void main(String[] args) {
        check(PhoenixPrintRules.totalPrintTicks(30, PhoenixPrintRules.Catalyst.NONE, false) == 600, "base 30s");
        check(PhoenixPrintRules.totalPrintTicks(30, PhoenixPrintRules.Catalyst.QUANTUM_ISOTOPE, false) == 200, "quantum is one third");
        check(PhoenixPrintRules.totalPrintTicks(30, PhoenixPrintRules.Catalyst.NONE, true) == 900, "corrupted is 1.5x");
        check(PhoenixPrintRules.totalPrintTicks(1, PhoenixPrintRules.Catalyst.QUANTUM_ISOTOPE, false) == 20, "minimum duration");
        check(PhoenixPrintRules.canStart(PhoenixPrintRules.State.IDLE, true, 32), "valid start");
        check(!PhoenixPrintRules.canStart(PhoenixPrintRules.State.BROKEN, true, 64), "broken cannot print");
        check(PhoenixPrintRules.canRepair(PhoenixPrintRules.State.BROKEN, 2, 1), "repair ingredients");

        PhoenixCapsuleProcess process = new PhoenixCapsuleProcess();
        UUID owner = UUID.randomUUID();
        check(process.start(owner, "test", 40, PhoenixPrintRules.Catalyst.QUANTUM_ISOTOPE, false, 30), "process starts");
        check(process.progress() == 0 && process.totalTicks() == 200, "process initialized");
        for (int i = 0; i < 199; i++) check(!process.tick(), "not ready early");
        check(process.tick(), "ready at tick 200");
        check(process.state() == PhoenixPrintRules.State.READY, "ready state");
        check(process.consumeForResurrection(), "resurrection consumes clone");
        check(process.state() == PhoenixPrintRules.State.BROKEN, "resurrection breaks capsule");
        check(process.repair(2, 1), "repair resets capsule");
        check(process.state() == PhoenixPrintRules.State.IDLE, "repair returns idle");

        PhoenixResurrectionFlash.Frame first = PhoenixResurrectionFlash.frame(0, 2400, PhoenixPrintRules.Catalyst.QUANTUM_ISOTOPE, false);
        check(first.visible() && first.flashAlpha() > 0.84f, "resurrection flash begins bright");
        check(first.flashColor().equals(new PhoenixResurrectionFlash.Rgb(120, 240, 255)), "quantum flash palette");
        check(!PhoenixResurrectionFlash.frame(2400, 2400, PhoenixPrintRules.Catalyst.NONE, false).visible(), "flash expires at duration");

        PhoenixCloneAnimation.Frame clonePrinting = PhoenixCloneAnimation.frame(10.0f, 0.5f, false, false);
        check(clonePrinting.verticalOffset() >= -0.05f && clonePrinting.verticalOffset() <= 0.05f,
                "printing clone bob stays within original amplitude");
        check(clonePrinting.opacity() >= 0.35f && clonePrinting.opacity() <= 0.9f,
                "printing clone opacity clamped");
        PhoenixCloneAnimation.Frame cloneReady = PhoenixCloneAnimation.frame(10.0f, 1.0f, true, true);
        check(cloneReady.scale() == 0.35f && cloneReady.opacity() == 0.94f,
                "ready clone scale and opacity match original renderer");
        check(Math.abs(cloneReady.verticalOffset()) <= 0.0451f,
                "ready clone bob stays within original amplitude");

        UUID dyingPlayer = UUID.randomUUID();
        check(PhoenixResurrectionRules.canResurrect(true, false, dyingPlayer, dyingPlayer),
                "matching ready capsule resurrects owner");
        check(!PhoenixResurrectionRules.canResurrect(false, false, dyingPlayer, dyingPlayer),
                "printing capsule cannot resurrect");
        check(!PhoenixResurrectionRules.canResurrect(true, true, dyingPlayer, dyingPlayer),
                "broken capsule cannot resurrect");
        check(!PhoenixResurrectionRules.canResurrect(true, false, UUID.randomUUID(), dyingPlayer),
                "capsule for another profile cannot resurrect");
        check(PhoenixResurrectionRules.capsuleSlotForArmorIndex(3) == PhoenixPrintRules.SLOT_HELMET,
                "helmet slot mapping");
        check(PhoenixResurrectionRules.capsuleSlotForArmorIndex(0) == PhoenixPrintRules.SLOT_FEET,
                "boots slot mapping");

        PhoenixCapsuleQueue queue = new PhoenixCapsuleQueue();
        PhoenixCapsuleQueue.Location loc = new PhoenixCapsuleQueue.Location("minecraft:overworld", 1, 2, 3);
        check(queue.register(owner, loc, 3, true), "queue registration");
        check(queue.register(owner, loc, 3, true), "duplicate registration idempotent");
        check(queue.popNext(owner).orElseThrow().equals(loc), "queue FIFO");
        check(!queue.hasCapsule(owner), "queue empties");
        System.out.println("Phoenix core self-test: PASS");
    }
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
