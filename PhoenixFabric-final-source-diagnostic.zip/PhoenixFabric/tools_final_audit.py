#!/usr/bin/env python3
"""Fast static final audit for the PhoenixFabric source checkpoint."""
from pathlib import Path
import json

root = Path(__file__).resolve().parent
errors = []

for path in (root / 'src/main/resources').rglob('*.json'):
    try:
        json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        errors.append(f'{path.relative_to(root)}: {exc}')

required = [
    'src/main/java/dev/phoenixfabric/block/entity/PhoenixCapsuleBlockEntity.java',
    'src/main/java/dev/phoenixfabric/menu/PhoenixCapsuleMenu.java',
    'src/client/java/dev/phoenixfabric/client/render/PhoenixCapsuleRenderer.java',
    'src/client/java/dev/phoenixfabric/client/screen/PhoenixCapsuleScreen.java',
    'src/main/java/dev/phoenixfabric/event/PhoenixResurrectionEvents.java',
    'src/main/java/dev/phoenixfabric/core/PhoenixCloneAnimation.java',
    'src/main/java/dev/phoenixfabric/core/PhoenixResurrectionFlash.java',
    'FINAL_AUDIT.md',
]
for rel in required:
    if not (root / rel).is_file():
        errors.append(f'missing required source: {rel}')

sound_dir = root / 'src/main/resources/assets/phoenixfabric/sounds'
for name in ('clone_print_loop.ogg', 'clone_ready.ogg', 'capsule_repair.ogg', 'capsule_shatter.ogg'):
    p = sound_dir / name
    if not p.is_file() or p.stat().st_size == 0:
        errors.append(f'missing/empty sound: {name}')

# Guard against a regression where only the six base player parts are rendered.
renderer = (root / 'src/client/java/dev/phoenixfabric/client/render/PhoenixCapsuleRenderer.java').read_text()
for part in ('model.hat', 'model.jacket', 'model.leftSleeve', 'model.rightSleeve', 'model.leftPants', 'model.rightPants'):
    if f'submitPart(collector, {part},' not in renderer:
        errors.append(f'player skin overlay layer is not rendered: {part}')

if errors:
    print('Phoenix final audit: FAIL')
    print('\n'.join(errors))
    raise SystemExit(1)
print('Phoenix final audit: PASS (static resources/source presence only; not a game build)')
