# Phoenix reference notes

The supplied JAR declares `modId = ricks_stuff`, version `0.0.4.3`, and Forge loader `[47,)`. It is not directly installable as a Fabric mod.

Original capsule recipe (`phoenix_capsule`):

```
GQG
GTG
NRN
```

- G = glass
- Q = quantum isotope
- T = totem of undying
- N = netherite ingot
- R = respawn anchor

The original blockstate defines 8 combinations for `facing` north/east/south/west and `broken` false/true, with 90-degree model rotations for horizontal facing.

Original English UI labels include “PHOENIX TERMINAL”, “PRINT CLONE”, “REPAIR TANK”, “SYNTHESIZING...”, “CLONE READY”, “STANDBY MODE”, and an equipment section.

## Stage 2 — core rules recovered and isolated (2026-10-09)

Added pure-Java core classes under `src/main/java/dev/phoenixfabric/core/` so recovered gameplay rules can be tested before binding to Minecraft/Fabric APIs:

- `PhoenixPrintRules`: original slot indices, 32-unit meat requirement, catalyst IDs, state gates, repair inputs, and print-time formula.
- `PhoenixCapsuleProcess`: server-side state machine for idle → printing → ready → broken on resurrection, plus repair reset.
- `PhoenixCapsuleQueue`: ordered owner UUID queue with dimension + block coordinates, duplicate suppression, max-count enforcement, unregister and FIFO pop semantics matching `PhoenixManager`.
- `PhoenixCoreSelfTest`: dependency-free smoke test covering timing modifiers, state transitions, repair and queue behavior.

### Rules verified from original bytecode

- Default print time is 30 seconds (600 ticks); config allows 1–600 seconds.
- Quantum isotope changes duration to `max(20, baseTicks / 3)`.
- Corrupted/rotten-flesh print duration is then multiplied by `1.5` and truncated to int.
- Starting a print requires an idle, unbroken capsule, a DNA sample flask containing a profile with UUID, and at least 32 raw-meat items. The original consumes 32 meat and one DNA flask, returns excess meat, and consumes one inserted catalyst at print start.
- Original repair requires 2 glass panes and 1 water bucket. A glass bottle is produced into the water slot if empty, otherwise returned to the player inventory or dropped.
- Completion registers the capsule in the owner's queue. Resurrection consumes the ready state and marks the capsule broken; a repaired capsule resets to idle.
- The original queue is persisted in world SavedData as `ricks_stuff_phoenix_queue`, grouped by player UUID; each entry stores packed block position and dimension ID.

### Verification

`PhoenixCoreSelfTest` is intended to be compiled/run independently of Minecraft dependencies. These classes are the extracted rules/state core; they are **not yet wired into a registered Fabric block entity, menu, death/respawn event, or renderer**. The requested Minecraft 1.26.3 dependency coordinates remain an unresolved version gate, so this stage is not represented as a playable mod.
