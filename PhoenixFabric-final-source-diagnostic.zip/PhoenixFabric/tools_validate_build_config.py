#!/usr/bin/env python3
"""Static checks for Fabric dependency scopes and version metadata; not a Gradle build."""
from pathlib import Path
import json

root = Path(__file__).resolve().parent
errors = []
build = (root / 'build.gradle').read_text(encoding='utf-8')
props = dict(line.split('=', 1) for line in (root / 'gradle.properties').read_text(encoding='utf-8').splitlines() if '=' in line and not line.lstrip().startswith('#'))
mod_json = json.loads((root / 'src/main/resources/fabric.mod.json').read_text(encoding='utf-8'))

if 'modImplementation "net.fabricmc:fabric-loader:${project.loader_version}"' not in build:
    errors.append('Fabric Loader must use Loom modImplementation dependency scope')
if 'modImplementation "net.fabricmc.fabric-api:fabric-api:${project.fabric_version}"' not in build:
    errors.append('Fabric API must use Loom modImplementation dependency scope')
if 'implementation "net.fabricmc:fabric-loader:' in build or 'implementation "net.fabricmc.fabric-api:' in build:
    errors.append('Found incorrect plain implementation scope for a Fabric mod dependency')
version = props.get('mod_version', '')
if not version.startswith('0.1.0-alpha.'):
    errors.append('mod_version must use the expected 0.1.0-alpha.N format')
if not version or mod_json.get('version') != '${version}':
    errors.append('Gradle version and fabric.mod.json expansion must be configured')
if '${version}' not in mod_json.get('version', ''):
    errors.append('fabric.mod.json version must be expanded from Gradle project version')
if 'options.release = 25' not in build or 'JavaLanguageVersion.of(25)' not in build:
    errors.append('Java 25 compile toolchain settings missing')

if errors:
    print('Phoenix build config validation: FAIL')
    print('\n'.join(errors))
    raise SystemExit(1)
print('Phoenix build config validation: PASS (static configuration only; Gradle build not run)')
