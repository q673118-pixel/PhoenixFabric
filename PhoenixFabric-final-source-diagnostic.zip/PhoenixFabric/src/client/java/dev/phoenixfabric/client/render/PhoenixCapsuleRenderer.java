package dev.phoenixfabric.client.render;

import dev.phoenixfabric.api.PhoenixCapsuleRenderAccess;
import dev.phoenixfabric.block.entity.PhoenixCapsuleBlockEntity;
import dev.phoenixfabric.core.PhoenixCloneAnimation;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import org.jspecify.annotations.Nullable;

/**
 * Port of the original Rick's Stuff PhoenixCapsuleRenderer for the Minecraft 26.3
 * submit-node rendering pipeline. The actual capsule block entity must implement
 * PhoenixCapsuleRenderAccess and register this renderer for its BlockEntityType.
 */
public final class PhoenixCapsuleRenderer implements BlockEntityRenderer<PhoenixCapsuleBlockEntity, PhoenixCapsuleRenderState> {
    private static final Identifier FALLBACK_SKIN = Identifier.withDefaultNamespace("textures/entity/player/wide/steve.png");

    private final PlayerModel wideModel;
    private final PlayerModel slimModel;

    public PhoenixCapsuleRenderer(BlockEntityRendererProvider.Context context) {
        this.wideModel = new PlayerModel(context.bakeLayer(ModelLayers.PLAYER), false);
        this.slimModel = new PlayerModel(context.bakeLayer(ModelLayers.PLAYER_SLIM), true);
    }

    @Override
    public PhoenixCapsuleRenderState createRenderState() {
        return new PhoenixCapsuleRenderState();
    }

    @Override
    public void extractRenderState(PhoenixCapsuleBlockEntity blockEntity, PhoenixCapsuleRenderState state,
                                   float partialTicks, Vec3 cameraPosition,
                                   @Nullable ModelFeatureRenderer.CrumblingOverlay breakProgress) {
        BlockEntityRenderState.extractBase(blockEntity, state, breakProgress);
        PhoenixCapsuleRenderAccess capsule = blockEntity;

        state.broken = capsule.phoenix$isBroken();
        state.printing = capsule.phoenix$isPrinting();
        state.ready = capsule.phoenix$isReady();
        state.progress = clamp(capsule.phoenix$getSmoothPrintProgress(partialTicks), 0.0f, 1.0f);
        state.yawDegrees = capsule.phoenix$getFacingYawDegrees();
        state.worldTimeTicks = blockEntity.getLevel() == null
                ? partialTicks
                : blockEntity.getLevel().getGameTime() + partialTicks;
        state.catalystType = capsule.phoenix$getCatalystType();
        Identifier texture = capsule.phoenix$getSkinTexture();
        state.skinTexture = texture == null ? FALLBACK_SKIN : texture;
        state.slimSkin = capsule.phoenix$isSlimSkin();
        state.subjectUuid = capsule.phoenix$getSubjectUuid();
        // Resolve the exact skin currently known to the client's authenticated
        // player list. This avoids substituting Steve for a captured player
        // while that profile is online in the current session.
        if (state.subjectUuid != null) {
            var connection = Minecraft.getInstance().getConnection();
            PlayerInfo info = connection == null ? null : connection.getPlayerInfo(state.subjectUuid);
            if (info != null && info.getSkin() != null) {
                PlayerSkin playerSkin = info.getSkin();
                state.skinTexture = playerSkin.texture();
                state.slimSkin = playerSkin.model() == PlayerSkin.Model.SLIM;
            }
        }
    }

    @Override
    public void submit(PhoenixCapsuleRenderState state, PoseStack poseStack,
                       SubmitNodeCollector collector, CameraRenderState camera) {
        if (state.broken || (!state.printing && !state.ready)) return;

        PlayerModel model = state.slimSkin ? slimModel : wideModel;
        resetAndPoseModel(model, state);

        PhoenixCloneAnimation.Frame animation = PhoenixCloneAnimation.frame(
                state.worldTimeTicks, state.progress, state.ready, state.catalystType == 4);

        poseStack.pushPose();
        float renderedBob = animation.verticalOffset();
        poseStack.translate(0.5, 0.22 + renderedBob, 0.5);
        poseStack.mulPose(Axis.YP.rotationDegrees(-state.yawDegrees + 180.0f));
        poseStack.scale(animation.scale(), animation.scale(), animation.scale());
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
        poseStack.translate(0.0, -1.65, 0.0);

        Identifier skin = state.skinTexture == null ? FALLBACK_SKIN : state.skinTexture;
        var renderType = RenderTypes.entityTranslucent(skin);
        int tint = ARGB.colorFromFloat(animation.opacity(), 1.0f, 1.0f, 1.0f);
        submitPart(collector, model.head, poseStack, renderType, state.lightCoords, tint);
        submitPart(collector, model.body, poseStack, renderType, state.lightCoords, tint);
        submitPart(collector, model.leftArm, poseStack, renderType, state.lightCoords, tint);
        submitPart(collector, model.rightArm, poseStack, renderType, state.lightCoords, tint);
        submitPart(collector, model.leftLeg, poseStack, renderType, state.lightCoords, tint);
        submitPart(collector, model.rightLeg, poseStack, renderType, state.lightCoords, tint);
        // The player skin's second layer carries hair, jacket, sleeves and trouser overlays.
        // Submit these separately: rendering only the six base parts silently drops that layer.
        submitPart(collector, model.hat, poseStack, renderType, state.lightCoords, tint);
        submitPart(collector, model.jacket, poseStack, renderType, state.lightCoords, tint);
        submitPart(collector, model.leftSleeve, poseStack, renderType, state.lightCoords, tint);
        submitPart(collector, model.rightSleeve, poseStack, renderType, state.lightCoords, tint);
        submitPart(collector, model.leftPants, poseStack, renderType, state.lightCoords, tint);
        submitPart(collector, model.rightPants, poseStack, renderType, state.lightCoords, tint);
        poseStack.popPose();
    }

    @Override
    public boolean shouldRenderOffScreen() {
        return true;
    }

    @Override
    public int getViewDistance() {
        return 96;
    }

    private static void submitPart(SubmitNodeCollector collector, ModelPart part, PoseStack poseStack,
                                   net.minecraft.client.renderer.rendertype.RenderType renderType,
                                   int light, int tint) {
        collector.submitModelPart(part, poseStack, renderType, light, OverlayTexture.NO_OVERLAY, null, tint, null);
    }

    private static void resetAndPoseModel(PlayerModel model, PhoenixCapsuleRenderState state) {
        model.head.resetPose();
        model.body.resetPose();
        model.leftArm.resetPose();
        model.rightArm.resetPose();
        model.leftLeg.resetPose();
        model.rightLeg.resetPose();
        model.hat.visible = true;
        model.jacket.visible = true;
        model.leftSleeve.visible = true;
        model.rightSleeve.visible = true;
        model.leftPants.visible = true;
        model.rightPants.visible = true;

        PhoenixCloneAnimation.Frame animation = PhoenixCloneAnimation.frame(
                state.worldTimeTicks, state.progress, state.ready, state.catalystType == 4);
        model.head.xRot = animation.headPitch();
        model.head.yRot = 0.0f;
        model.head.zRot = 0.0f;
        model.rightArm.xRot = 0.1f;
        model.rightArm.zRot = animation.rightArmRoll();
        model.leftArm.xRot = 0.1f;
        model.leftArm.zRot = animation.leftArmRoll();
        model.rightLeg.xRot = animation.rightLegPitch();
        model.leftLeg.xRot = animation.leftLegPitch();
        model.rightLeg.zRot = animation.rightLegRoll();
        model.leftLeg.zRot = animation.leftLegRoll();
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
