package dev.phoenixfabric.registry;

import dev.phoenixfabric.PhoenixFabric;
import dev.phoenixfabric.block.PhoenixCapsuleBlock;
import dev.phoenixfabric.block.entity.PhoenixCapsuleBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class PhoenixBlocks {
    private PhoenixBlocks() {}

    public static final Identifier CAPSULE_ID = Identifier.fromNamespaceAndPath(PhoenixFabric.MOD_ID, "phoenix_capsule");
    public static final ResourceKey<Block> CAPSULE_BLOCK_KEY = ResourceKey.create(Registries.BLOCK, CAPSULE_ID);
    public static final ResourceKey<Item> CAPSULE_ITEM_KEY = ResourceKey.create(Registries.ITEM, CAPSULE_ID);

    public static final Block PHOENIX_CAPSULE = Registry.register(
            BuiltInRegistries.BLOCK,
            CAPSULE_ID,
            new PhoenixCapsuleBlock(BlockBehaviour.Properties.of().setId(CAPSULE_BLOCK_KEY)
                    .strength(3.5F).noOcclusion())
    );

    public static final Item PHOENIX_CAPSULE_ITEM = Registry.register(
            BuiltInRegistries.ITEM,
            CAPSULE_ID,
            new BlockItem(PHOENIX_CAPSULE, new Item.Properties().setId(CAPSULE_ITEM_KEY).useBlockDescriptionPrefix())
    );

    public static final BlockEntityType<PhoenixCapsuleBlockEntity> PHOENIX_CAPSULE_ENTITY = Registry.register(
            BuiltInRegistries.BLOCK_ENTITY_TYPE,
            Identifier.fromNamespaceAndPath(PhoenixFabric.MOD_ID, "phoenix_capsule"),
            FabricBlockEntityTypeBuilder.create(PhoenixCapsuleBlockEntity::new, PHOENIX_CAPSULE).build()
    );

    public static void initialize() {
        PhoenixFabric.LOGGER.info("Registered Phoenix capsule block, item and block entity.");
    }
}
