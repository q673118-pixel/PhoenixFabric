# Phoenix Protocol — Fabric port (final source checkpoint alpha.12)

**Target requested:** Minecraft Java Edition `26.3` + Fabric.  
**Reference archive:** `ricks_stuff-0.0.4.3 (1).jar` (Forge 1.20.1).

## Alpha.9 — DNA capture and live skin/model resolution

- The DNA flask can now be used on a player to capture their UUID and profile name into the flask's persistent custom data. Non-player entities are rejected.
- Capture provides localized action-bar feedback in English and Russian.
- The capsule render contract now carries the stored subject UUID to the client renderer.
- While the subject is present in the current client's player list, the renderer resolves their actual downloaded skin texture and wide/slim model from the session's `PlayerInfo`, instead of always drawing Steve.
- Added `tools_validate_dna.py` for structural checks.

## Alpha.8 — capsule menu and operation screen

- Added and registered a native `PhoenixCapsuleMenu` with the recovered 11-slot mapping, player inventory, hotbar, shift-click transfer, and server-side validity checks.
- The capsule Block Entity now implements `MenuProvider`; interacting with the capsule opens the menu.
- Added the localized `PhoenixCapsuleScreen` with a custom terminal-style background, separate print/repair buttons, and a visual layout for input, repair, equipment, player inventory and hotbar slots.
- Print and repair buttons call the server menu-button handler; print uses the validated `tryBeginPrint(30)` path and repair calls `tryRepair()`.
- Added an English/Russian menu texture and localization strings.
- Added `tools_validate_menu.py` for structural checks.

## What remains incomplete

This remains an **unverified source checkpoint**, not a playable `.jar`. The screen/menu source has not been compiled against the target game because this environment does not have Gradle and only has Java 21, while the requested target requires Java 25. Therefore Minecraft 26.3 method signatures and the runtime opening/rendering flow still need an actual Gradle compile and in-game test.

The next implementation work is persistent skin resolution for offline subjects (including profile/texture cache behavior), live status/progress labels and failure feedback in the screen, original audio/laser effects, and resurrection/death restoration. These must be tested in a running game before calling the port complete.

## Validation available in this environment

- `python tools_validate_assets.py` — validates JSON resources.
- `python tools_validate_menu.py` — checks menu/screen registration and action wiring structurally.
- `python tools_validate_dna.py` — checks DNA capture and online skin/model resolution wiring structurally.
- Dependency-free Java core tests can be run with `javac` over `src/main/java/dev/phoenixfabric/core/*.java` and `src/test/java/dev/phoenixfabric/core/*.java`.

Passing these checks does **not** prove the Fabric mod compiles or launches.

## Alpha.10 — resurrection/death event
The server death hook is now wired to search loaded dimensions for a ready, intact capsule with a matching DNA UUID. On a match, death is cancelled, the player is restored and teleported to the capsule, the six saved equipment slots are swapped with the player's equipment, and the capsule is marked broken. This prevents losing the player's old gear while preserving the capsule loadout. Pure Java tests cover matching/mismatching profiles and capsule state selection.

**Not yet verified in Minecraft 26.3:** the project has not been compiled against the target Fabric/Minecraft dependencies or launched in-game in this environment. Treat alpha.10 as source code requiring build/runtime validation, not a finished installable mod.


## Alpha.11 — original sound assets and event wiring

- Extracted the four original capsule audio assets (`clone_print_loop`, `clone_ready`, `capsule_repair`, `capsule_shatter`) from the supplied reference JAR without re-encoding them.
- Registered the matching namespaced Fabric/Minecraft sound events.
- Wired the print-start sound, print-completion sound, repair sound, and breach/shatter sound to their server-side transitions. Duplicate shatter playback was avoided by making the Block Entity state transition the single source of that sound.
- Added `tools_validate_sounds.py` to check resource files, `sounds.json`, sound-event registration and transition wiring.

### Remaining limitations after alpha.11

- The `clone_print_loop.ogg` asset is currently triggered once when printing starts; continuous client-side looping has not yet been implemented.
- The recovered resurrection flash timing/color math exists as pure Java, but an in-game HUD overlay/packet path has not yet been wired.
- The laser/scan visual effect is not yet implemented.
- No actual Gradle compile or Minecraft 26.3 launch has been performed in this environment; this is still a source archive, not a verified installable JAR.


## Alpha.12 — final planned checkpoint and audit

This checkpoint consolidates the previous alpha stages and refreshes the project version. The following offline checks were run in the authoring environment:

- `python tools_validate_assets.py` — PASS
- `python tools_validate_menu.py` — PASS
- `python tools_validate_dna.py` — PASS
- `python tools_validate_sounds.py` — PASS
- Compile dependency-free core/test classes with `javac` and run `PhoenixCoreSelfTest` — PASS
- ZIP integrity check — PASS

**Release status: NOT A VERIFIED GAME BUILD.** This environment has Java 21 and no installed Gradle executable/wrapper; the project targets Java 25 and Minecraft 26.3. Therefore a Minecraft/Fabric compile, client launch, real block/menu/render testing, and in-game resurrection testing could not be performed. Do not install this source ZIP as a mod; it is a source project.

Known functional gaps that remain before a true release: (1) continuous looping playback for `clone_print_loop.ogg`; (2) connecting `PhoenixResurrectionFlash` to the live HUD; (3) scan/laser effect; (4) online-only skin resolution fallback for offline profiles; (5) real compilation and in-game verification of all target-version API calls.

### alpha.13 follow-up
The renderer now submits the player's second skin layer (hat/hair overlay, jacket, sleeves, and trouser overlays) in addition to the six base body parts. `tools_final_audit.py` checks that these submissions remain present. This is not a substitute for testing with an actual player skin in Minecraft.


## Alpha.14 — Fabric dependency configuration correction

- Corrected the Fabric Loader and Fabric API dependency scopes from plain Gradle `implementation` to Loom `modImplementation`, so Loom treats them as mod dependencies and remaps/resolves them through the Fabric development setup.
- Added `tools_validate_build_config.py` to guard dependency scopes, Java 25 toolchain settings, and version metadata.
- This remains a static configuration correction only: no Gradle executable/wrapper or Java 25 runtime is available here, so dependency resolution and Minecraft compilation were not executed.

## Reproducible build check (alpha.16)

A GitHub Actions workflow now attempts a real Gradle build using Temurin Java 25 and Gradle 9.6 whenever the repository is pushed, on pull requests, or manually dispatched. If compilation succeeds, it uploads the generated JAR as a workflow artifact. This environment cannot execute that workflow itself, so adding CI is not evidence that the target-version build passes.

Local build command with Java 25 and Gradle 9.6 installed:

```bash
gradle --no-daemon clean build --stacktrace
```

The deliverable archive remains source code until the build job succeeds and the resulting JAR is tested in Minecraft 26.3.


### Run all offline checks

```bash
python tools_run_all_checks.py
```

This runs static resource/configuration checks and the pure-Java core tests. It does not compile Minecraft/Fabric integration sources or launch the game.
