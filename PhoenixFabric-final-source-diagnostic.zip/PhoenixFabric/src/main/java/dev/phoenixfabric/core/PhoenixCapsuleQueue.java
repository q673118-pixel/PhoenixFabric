package dev.phoenixfabric.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/** Ordered, owner-specific capsule queue matching PhoenixManager's behavior. */
public final class PhoenixCapsuleQueue {
    public record Location(String dimensionId, int x, int y, int z) {
        public Location { Objects.requireNonNull(dimensionId, "dimensionId"); }
    }

    private final Map<UUID, ArrayDeque<Location>> queues = new HashMap<>();

    public synchronized boolean register(UUID owner, Location location, int maxCapsules, boolean protocolEnabled) {
        if (!protocolEnabled || owner == null || location == null) return false;
        ArrayDeque<Location> queue = queues.computeIfAbsent(owner, ignored -> new ArrayDeque<>());
        if (queue.contains(location)) return true;
        if (queue.size() >= Math.max(1, maxCapsules)) return false;
        queue.addLast(location);
        return true;
    }

    public synchronized void unregister(UUID owner, Location location) {
        if (owner == null || location == null) return;
        ArrayDeque<Location> queue = queues.get(owner);
        if (queue == null) return;
        queue.remove(location);
        if (queue.isEmpty()) queues.remove(owner);
    }

    public synchronized boolean hasCapsule(UUID owner) {
        ArrayDeque<Location> queue = queues.get(owner);
        return queue != null && !queue.isEmpty();
    }

    public synchronized Optional<Location> popNext(UUID owner) {
        ArrayDeque<Location> queue = queues.get(owner);
        if (queue == null || queue.isEmpty()) return Optional.empty();
        Location next = queue.removeFirst();
        if (queue.isEmpty()) queues.remove(owner);
        return Optional.of(next);
    }

    public synchronized List<Location> snapshot(UUID owner) {
        ArrayDeque<Location> queue = queues.get(owner);
        return queue == null ? List.of() : List.copyOf(new ArrayList<>(queue));
    }
}
