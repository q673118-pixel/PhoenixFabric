package dev.phoenixfabric.api;

import net.minecraft.resources.Identifier;
import java.util.UUID;

/**
 * Client render snapshot contract implemented by the capsule block entity.
 * Keeping this separate from the renderer prevents the client-only skin/model
 * classes from leaking into common/server code.
 */
public interface PhoenixCapsuleRenderAccess {
    boolean phoenix$isBroken();
    boolean phoenix$isPrinting();
    boolean phoenix$isReady();
    float phoenix$getSmoothPrintProgress(float partialTick);
    int phoenix$getCatalystType();
    float phoenix$getFacingYawDegrees();
    Identifier phoenix$getSkinTexture();
    boolean phoenix$isSlimSkin();
    UUID phoenix$getSubjectUuid();
}
