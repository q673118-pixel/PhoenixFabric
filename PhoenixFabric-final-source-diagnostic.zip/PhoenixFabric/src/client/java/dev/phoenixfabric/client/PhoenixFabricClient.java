package dev.phoenixfabric.client;

import dev.phoenixfabric.PhoenixFabric;
import dev.phoenixfabric.client.render.PhoenixCapsuleRenderer;
import dev.phoenixfabric.registry.PhoenixBlocks;
import dev.phoenixfabric.registry.PhoenixMenus;
import dev.phoenixfabric.client.screen.PhoenixCapsuleScreen;
import net.minecraft.client.gui.screens.MenuScreens;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;

/** Client-side registration for the live clone-in-capsule renderer. */
public final class PhoenixFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockEntityRenderers.register(PhoenixBlocks.PHOENIX_CAPSULE_ENTITY, PhoenixCapsuleRenderer::new);
        MenuScreens.register(PhoenixMenus.PHOENIX_CAPSULE, PhoenixCapsuleScreen::new);
        PhoenixFabric.LOGGER.info("Registered Phoenix capsule renderer, menu, and operation screen.");
    }
}
