# Phoenix system recovered from Rick's Stuff 0.0.4.3

This note records what is actually present in the supplied Forge JAR. It is intentionally explicit about the difference between original behavior and any future enhancement.

## Clone: what the original really does

The original does not register a separate world `Entity` for the clone, but it **does render a player-model clone inside the capsule** using `client.renderer.PhoenixCapsuleRenderer`. My earlier conclusion that the visible clone was only a narrative/UI metaphor was incorrect; the renderer is present in the JAR and must be ported for visual parity.

1. `PhoenixCapsuleRenderer` creates both standard (Steve) and slim (Alex) `PlayerModel`s, resolves the DNA subject's skin/profile, and renders that player model inside the intact capsule while printing or when ready.
2. While printing, the clone bobs with `sin(worldTime * 0.15) * 0.05` vertical offset. Its opacity is clamped from `0.4 + smoothProgress * 0.45 + bob` to `[0.35, 0.9]`.
3. When ready, it bobs more gently with `sin(worldTime * 0.06) * 0.045`, at opacity `0.94`.
4. The head pitch is `0.22 + sin(worldTime * 0.04) * 0.03`; the arms have opposite subtle rolls based on `cos(worldTime * 0.03) * 0.02`. The legs use fixed slight bends/rolls. Normal clone scale is `0.7`; catalyst type 4 (quantum isotope in the renderer) uses `0.35`.
5. The renderer resolves online skin/model metadata from player info where available, falls back to `SkinManager` for the saved `GameProfile`, and finally to a default player skin. The port must preserve this path as closely as the target API allows.
6. This visual clone is separate from the resurrection mechanic: `startPrinting` stores the subject's UUID/name/profile, and successful completion registers the ready capsule in `PhoenixManager` under that UUID.
7. `CommonEvents.onLivingDeath(LivingDeathEvent)` checks for a ready capsule. If found, it cancels death, heals the player, moves them to capsule center X/Z and Y + 0.2, restores the capsule's saved equipment, then breaks the capsule. Repair uses 2 glass panes + 1 water bucket; the empty bucket is returned as a glass bottle if the water slot is empty, otherwise the bottle is returned/dropped.

## Original animation / visual feedback

- The capsule shell has two static block-model variants: intact and broken; the player-shaped clone is drawn separately by `PhoenixCapsuleRenderer`.
- `PhoenixCapsuleBlockEntity` keeps `prevClientPrintProgress`, `clientPrintProgress` and `getSmoothPrintProgress(partialTick)`, so the client interpolates print progress smoothly rather than stepping only once per server tick.
- `reference/decompiled/PhoenixCapsuleRenderer.javap.txt` contains the recovered renderer bytecode. `PhoenixCloneAnimation` in the Fabric source models the original bobbing, limb poses, opacity and scale; a live Fabric block-entity renderer still has to apply these values in-game.
- The print UI has state labels for `STANDBY MODE`, `SYNTHESIZING...`, `CLONE READY`, and `BREACHED`, plus a progress indicator, catalyst state, meat/DNA requirements and a six-slot equipment loadout.
- `PhoenixResurrectionOverlay.trigger(durationMs, catalyst, corrupted)` runs a short full-screen flash overlay. Default duration is 2400 ms. Its first 400 ms is a fade; color varies by catalyst (quantum blue/teal, golden apple yellow/orange, corrupted brown/olive, default pink/red). The overlay adds edge bars and timed fade transitions.
- The original uses `clone_print_loop.ogg`, `clone_ready.ogg`, `capsule_repair.ogg`, and `capsule_shatter.ogg`.

## Inventory slots recovered from the original

| Slot | Purpose |
|---:|---|
| 0 | Raw meat input |
| 1 | Glass panes for repair |
| 2 | Water bucket for repair |
| 3 | Optional catalyst |
| 4 | DNA sample flask with a profile |
| 5 | Helmet to restore |
| 6 | Chest armor to restore |
| 7 | Leg armor to restore |
| 8 | Boots to restore |
| 9 | Main-hand item to restore |
| 10 | Off-hand item to restore |

## Printing rules

- Base duration: `max(20 ticks, configuredSeconds * 20)`; original config default is 30 seconds and range is 1–600 seconds.
- Quantum isotope catalyst: divide adjusted base duration by 3, with a 20-tick minimum.
- Corrupted material: multiply the catalyst-adjusted duration by 1.5 and truncate to integer.
- Start requires idle/unbroken state, a DNA sample flask that has a profile, and at least 32 accepted raw meat.
- One catalyst is consumed at print start; the DNA flask is consumed; exactly 32 meat is consumed and excess meat is returned.
- Other catalyst types (golden apple, enchanted golden apple, dark matter dust) affect resurrection flash color but do not shorten print time in `getTotalPrintTicks()`.

## Resource-port correction in alpha.3

The original block model files are Blockbench/Bedrock-flavored JSON (`format_version`, `texture_size`, numeric texture key `0`). Java block model JSON does not use that schema. Alpha.3 converts the model JSON to Java format, maps the texture variable to `#0`, and fixes blockstate model references from the original `ricks_stuff` namespace to `phoenixfabric`. The item model now inherits the Java block model rather than repeating the Bedrock-style JSON.

## Parity boundary

The original is Forge 1.20.1. It has to be adapted to Fabric APIs and the requested Minecraft target. A successful pure-Java logic test or valid JSON is not proof that a Fabric game build launches. The requested `1.26.3` dependency coordinates still need to be verified by a Gradle build in an environment with Fabric Maven access.

## Alpha.5 renderer adapter work

- Added a client-only `PhoenixCapsuleRenderer` written against the Minecraft 26.3 submit-node renderer (`BlockEntityRenderer` with `createRenderState`, `extractRenderState`, and `submit`). It creates both `PlayerModel` variants and submits the six body roots with the matching skin texture, light, translucent tint, and original transform. The ready clone is physically bobbed; during printing, the original renderer uses the faster sine term for opacity only and does not translate the model vertically.
- It uses the already-tested `PhoenixCloneAnimation.frame(...)` as the single source of truth for bobbing, opacity, head/arm/leg pose, and scale. The capsule block entity is expected to expose its smooth progress and skin through `PhoenixCapsuleRenderAccess`.
- The render adapter is **not registered or game-tested yet**. Registration depends on implementing and registering the actual capsule `BlockEntityType`; owner GameProfile/skin lookup and network/persistence also have to be connected to the render-access contract. The original scan laser is not yet included in this adapter.
- Build files now follow the current Fabric 26.3 template direction: unobfuscated Mojang names (no Yarn mappings), split main/client source sets, Java 25, Loom 1.17, Loader 0.19.5 and Fabric API 0.160.5+26.3. These versions are aligned to the current published template/version information but could not be resolved or compiled in this sandbox because it has Java 21, no installed Gradle, and no outbound Maven DNS.


## Alpha.7 inventory integration

The Fabric Block Entity now implements Minecraft's `Container` contract and persists all eleven inventory slots. `PhoenixDnaFlaskItem` stores a subject UUID and name in `minecraft:custom_data`; `PhoenixCapsuleBlockEntity.tryBeginPrint` validates state, profile-bearing DNA flask, and at least 32 accepted raw meat, then consumes 32 meat, one DNA flask, and one optional catalyst. Catalyst duration follows `PhoenixPrintRules`; rotten flesh is treated as corrupted material. Custom DNA/catalyst items are registered. The UI, profile capture flow, exact skin lookup, repair action, and resurrection/death hook are not yet wired.

The same stage adds `tryRepair`, which requires two glass panes and one water bucket, consumes those inputs, returns a glass bottle, clears the broken state, and plays a temporary placeholder glass sound. Exact original repair sound replacement is still pending.

## Alpha.8 menu implementation

- The capsule Block Entity implements `MenuProvider`, and the block opens it through the normal right-click container interaction.
- `PhoenixCapsuleMenu` maps the original 11 capsule slots, exposes the player inventory/hotbar, and includes shift-click handling that respects each capsule slot's `Container.canPlaceItem` rule.
- Menu button 0 calls the server-validated print transition; button 1 calls the server-validated repair transition.
- The client screen and terminal background are registered through Fabric's menu-screen registration.
- This is source-level integration only until a Minecraft 26.3 Gradle build and in-game test are run.


## Port progress note — alpha.9 DNA profile capture

The port now supports right-clicking a live player with the DNA flask. The flask stores that player's UUID and profile name in persistent item custom data; using the flask on non-player living entities returns PASS. The capsule's client render snapshot carries the stored UUID and resolves the live `PlayerInfo` skin texture/model when that player is available in the client's current session. If the subject is not present in the client's player list, the renderer currently falls back to the saved/default texture (usually Steve); offline profile texture lookup/cache is still outstanding. Structural checks cover the capture, UUID contract, skin texture selection, and slim-model branch, but this source has not been compiled or tested in a launched Minecraft 26.3 instance.

## Alpha.10 — resurrection event wiring
- Added a Fabric `ServerLivingEntityEvents.ALLOW_DEATH` handler for player deaths.
- The handler looks for a loaded, ready, unbroken capsule whose stored DNA UUID matches the dying player's UUID, across server dimensions.
- When found, it prevents death, heals/restores food, teleports the player to the capsule, swaps the capsule's six saved equipment slots with the player's current equipment (avoiding item deletion/duplication), and marks the capsule broken.
- The handler is registered from the main mod initializer. Pure-Java tests cover the selection rules and armor slot mapping.
- Runtime caveat: the Fabric/Minecraft source set has not been compiled against Minecraft 26.3 in this environment, so event/API compatibility and the full in-game death flow still require a real Gradle build and game test. This is an implementation step, not a verified finished runtime.


## Alpha.11 implementation note — audio integration

The exact four capsule OGG assets were extracted from the original JAR and placed under `assets/phoenixfabric/sounds/`. Sound events are registered by `PhoenixSounds`; print start, print completion, repair and breach transitions now invoke them. The print loop event currently starts as a one-shot rather than a continuous loop. HUD resurrection overlay and scanning laser remain outstanding runtime effects and must not be described as finished.
