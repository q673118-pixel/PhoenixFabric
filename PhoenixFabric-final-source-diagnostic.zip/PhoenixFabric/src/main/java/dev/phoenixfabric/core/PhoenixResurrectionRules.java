package dev.phoenixfabric.core;

import java.util.Objects;
import java.util.UUID;

/** Pure decision rules for selecting a capsule for the original resurrection flow. */
public final class PhoenixResurrectionRules {
    private PhoenixResurrectionRules() {}

    /** A capsule only resurrects the player whose profile was used to print it. */
    public static boolean canResurrect(boolean ready, boolean broken, UUID capsuleSubject, UUID dyingPlayer) {
        return ready && !broken && capsuleSubject != null && dyingPlayer != null
                && Objects.equals(capsuleSubject, dyingPlayer);
    }

    /** Equipment slots in the capsule inventory, in the order used by the original menu. */
    public static int capsuleSlotForArmorIndex(int armorIndex) {
        return switch (armorIndex) {
            case 3 -> PhoenixPrintRules.SLOT_HELMET;
            case 2 -> PhoenixPrintRules.SLOT_CHEST;
            case 1 -> PhoenixPrintRules.SLOT_LEGS;
            case 0 -> PhoenixPrintRules.SLOT_FEET;
            default -> throw new IllegalArgumentException("armor index must be in [0, 3]");
        };
    }
}
