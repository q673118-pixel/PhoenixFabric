package dev.phoenixfabric.event;

import dev.phoenixfabric.block.entity.PhoenixCapsuleBlockEntity;
import dev.phoenixfabric.core.PhoenixPrintRules;
import dev.phoenixfabric.core.PhoenixResurrectionRules;
import dev.phoenixfabric.registry.PhoenixBlocks;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.sounds.SoundSource;

import java.util.Optional;
import java.util.UUID;

/** Server-side death interception matching the reference mod's ready-capsule resurrection. */
public final class PhoenixResurrectionEvents {
    private PhoenixResurrectionEvents() {}

    public static void register() {
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, damageAmount) -> {
            if (!(entity instanceof ServerPlayer player)) return true;
            return !tryResurrect(player);
        });
    }

    private static boolean tryResurrect(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) return false;
        UUID playerId = player.getUUID();
        Optional<CapsuleRef> candidate = findReadyCapsule(server, playerId);
        if (candidate.isEmpty()) return false;

        CapsuleRef ref = candidate.get();
        PhoenixCapsuleBlockEntity capsule = ref.capsule();
        ServerLevel targetLevel = ref.level();
        BlockPos pos = ref.pos();

        // Swap, rather than overwrite, all six saved equipment slots. This preserves
        // the dying player's current gear inside the breached capsule and avoids item loss.
        swapArmor(player, capsule, 3, PhoenixPrintRules.SLOT_HELMET);
        swapArmor(player, capsule, 2, PhoenixPrintRules.SLOT_CHEST);
        swapArmor(player, capsule, 1, PhoenixPrintRules.SLOT_LEGS);
        swapArmor(player, capsule, 0, PhoenixPrintRules.SLOT_FEET);
        swapMainHand(player, capsule);
        swapOffHand(player, capsule);

        // The original moves the player to the capsule, fully heals them, then breaches it.
        player.setHealth(player.getMaxHealth());
        player.getFoodData().setFoodLevel(20);
        player.getFoodData().setSaturation(5.0F);
        player.fallDistance = 0.0F;

        capsule.setBroken(true);
        player.teleportTo(targetLevel, pos.getX() + 0.5D, pos.getY() + 0.2D, pos.getZ() + 0.5D,
                java.util.Set.of(), player.getYRot(), player.getXRot());
        player.setHealth(player.getMaxHealth());
        return true;
    }

    private static Optional<CapsuleRef> findReadyCapsule(MinecraftServer server, UUID playerId) {
        // Scan every server dimension, so capsules in another dimension are supported too.
        // Only loaded block entities are considered, just as the original manager's live queue did.
        for (ServerLevel level : server.getAllLevels()) {
            for (BlockEntity blockEntity : level.blockEntityList) {
                if (!(blockEntity instanceof PhoenixCapsuleBlockEntity capsule)) continue;
                if (!PhoenixResurrectionRules.canResurrect(capsule.phoenix$isReady(), capsule.phoenix$isBroken(),
                        capsule.phoenix$getSubjectUuid(), playerId)) continue;
                BlockPos pos = capsule.getBlockPos();
                BlockState state = level.getBlockState(pos);
                if (state.is(PhoenixBlocks.PHOENIX_CAPSULE)) return Optional.of(new CapsuleRef(level, pos, capsule));
            }
        }
        return Optional.empty();
    }

    private static void swapArmor(ServerPlayer player, PhoenixCapsuleBlockEntity capsule, int armorIndex, int capsuleSlot) {
        ItemStack current = player.getInventory().armor.get(armorIndex);
        player.getInventory().armor.set(armorIndex, capsule.getItem(capsuleSlot).copy());
        capsule.setItem(capsuleSlot, current.copy());
    }

    private static void swapMainHand(ServerPlayer player, PhoenixCapsuleBlockEntity capsule) {
        int selected = player.getInventory().getSelectedSlot();
        ItemStack current = player.getInventory().getItem(selected);
        player.getInventory().setItem(selected, capsule.getItem(PhoenixPrintRules.SLOT_MAINHAND).copy());
        capsule.setItem(PhoenixPrintRules.SLOT_MAINHAND, current.copy());
    }

    private static void swapOffHand(ServerPlayer player, PhoenixCapsuleBlockEntity capsule) {
        ItemStack current = player.getInventory().offhand.get(0);
        player.getInventory().offhand.set(0, capsule.getItem(PhoenixPrintRules.SLOT_OFFHAND).copy());
        capsule.setItem(PhoenixPrintRules.SLOT_OFFHAND, current.copy());
    }

    private record CapsuleRef(ServerLevel level, BlockPos pos, PhoenixCapsuleBlockEntity capsule) {}
}
